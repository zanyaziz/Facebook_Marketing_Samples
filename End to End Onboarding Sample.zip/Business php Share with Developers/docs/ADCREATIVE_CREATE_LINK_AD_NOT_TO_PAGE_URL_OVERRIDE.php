<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */
namespace FacebookAdsDocs;

use FacebookAdsDoc\Helper\AdImageCreationHelper;
use FacebookAdsDocsmith\Test\DocsmithTestTrait;
use FacebookAdsTest\Config\Config;

/** @var DocsmithTestTrait $test */
/** @var Config $config */

$image_hash = (new AdImageCreationHelper())->getHash();
$ad_account_id = $config->accountId;

// _DOC oncall [alexlupu]
// _DOC open [ADCREATIVE_CREATE_LINK_AD_NOT_TO_PAGE_URL_OVERRIDE]
// _DOC vars [ad_account_id:s, image_hash:s]
use FacebookAds\Object\AdCreative;
use FacebookAds\Object\Fields\AdCreativeFields;

$creative = new AdCreative(null, $ad_account_id);

$creative->setData(array(
  AdCreativeFields::NAME => 'Sample Creative',
  AdCreativeFields::TITLE => 'my title',
  AdCreativeFields::BODY => 'my body',
  AdCreativeFields::OBJECT_URL => 'https://www.link.com',
  AdCreativeFields::LINK_URL => 'https://www.link.com',
  AdCreativeFields::IMAGE_HASH => $image_hash,
  'link_destination_display_url' => 'https://www.example.com',
));

$creative->create();
// _DOC close [ADCREATIVE_CREATE_LINK_AD_NOT_TO_PAGE_URL_OVERRIDE]

$creative->deleteSelf();
