<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;

use FacebookAdsDoc\Helper\AdsPixelHelper;
use FacebookAdsDoc\Helper\BusinessUnsharePixelHelper;
use FacebookAdsDocsmith\Test\DocsmithTestTrait;
use FacebookAdsTest\Config\Config;

/** @var DocsmithTestTrait $test */
/** @var Config $config */

$business_id = $config->businessId;
$agency_id = $config->secondaryBusinessId;
$pixel_id = (new AdsPixelHelper())->getPixelId();

$test->failIf(
  empty($agency_id), 'Secondary business id not provided by config');

// You can only share pixels that are not shared already
// Unshare if shared, than restore < ugly but safe
(new BusinessUnsharePixelHelper($pixel_id))->unshare();

$pixel = new \FacebookAds\Object\AdsPixel($pixel_id);
$pixel->sharePixelWithAgency($business_id, $agency_id);

// _DOC oncall [pruno]
// _DOC open [ADSPIXEL_UNSHARE_BUSINESS]
// _DOC vars [business_id, agency_id, pixel_id]
use FacebookAds\Object\AdsPixel;

$pixel = new AdsPixel($pixel_id);
$pixel->unsharePixelWithAgency($business_id, $agency_id);
// _DOC close [ADSPIXEL_UNSHARE_BUSINESS]
