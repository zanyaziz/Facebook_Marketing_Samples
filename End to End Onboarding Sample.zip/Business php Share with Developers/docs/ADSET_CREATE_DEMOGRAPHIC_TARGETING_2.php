<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;

use FacebookAds\Object\Fields\CampaignFields;
use FacebookAds\Object\Values\CampaignObjectiveValues;
use FacebookAdsDoc\Helper\CampaignCreationHelper;
use FacebookAdsTest\Config\Config;

/** @var Config $config */

$ad_account_id = $config->accountId;
$page_id = $config->pageId;
$campaign_id = (new CampaignCreationHelper(array(
  CampaignFields::OBJECTIVE => CampaignObjectiveValues::LINK_CLICKS,
)))->getId();

// _DOC oncall [paulbain]
// _DOC open [ADSET_CREATE_DEMOGRAPHIC_TARGETING_2]
// _DOC vars [ad_account_id:s, campaign_id, page_id]
use FacebookAds\Object\AdSet;
use FacebookAds\Object\Fields\AdSetFields;
use FacebookAds\Object\Fields\TargetingFields;
use FacebookAds\Object\Targeting;
use FacebookAds\Object\Values\AdSetOptimizationGoalValues;
use FacebookAds\Object\Values\AdSetBillingEventValues;


$adset = new AdSet(null, $ad_account_id);
$adset->setData(array(
  AdSetFields::NAME => 'My First AdSet',
  AdSetFields::DAILY_BUDGET => 10000,
  AdSetFields::BID_AMOUNT => 300,
  AdSetFields::BILLING_EVENT => AdSetBillingEventValues::IMPRESSIONS,
  AdSetFields::OPTIMIZATION_GOAL => AdSetOptimizationGoalValues::REACH,
  AdSetFields::CAMPAIGN_ID => $campaign_id,
  AdSetFields::PROMOTED_OBJECT => array(
    'page_id' => $page_id,
  ),
  AdSetFields::TARGETING => (new Targeting())->setData(array(
    TargetingFields::GEO_LOCATIONS => array(
      'countries' => array('JP'),
      'regions' => array(array('key' => '3886')),
      'cities' => array(
        array(
          'key' => '2420605',
          'radius' => 10,
          'distance_unit' => 'mile',
        ),
      ),
    ),
    TargetingFields::GENDERS => array(1),
    TargetingFields::AGE_MIN => 20,
    TargetingFields::AGE_MAX => 24,
    TargetingFields::PUBLISHER_PLATFORMS => array(
      'facebook',
      'audience_network',
    ),
    TargetingFields::DEVICE_PLATFORMS => array('mobile'),
    TargetingFields::INTERESTS => array(
      array(
        'id' => 6003107902433,
        'name' => 'Association football (Soccer)',
      ),
    ),
    TargetingFields::BEHAVIORS => array(
      array(
        'id' => 6002714895372,
        'name' => 'All frequent travelers',
      ),
    ),
    TargetingFields::LIFE_EVENTS => array(
      array(
        'id' => 6002714398172,
        'name' => 'Newlywed (1 year)',
      ),
    ),
    TargetingFields::HOME_OWNERSHIP => array(
      array(
        'id' => 6006371327132,
        'name' => 'Renters',
      ),
    ),
  )),
));


$adset->create(array(
  AdSet::STATUS_PARAM_NAME => AdSet::STATUS_PAUSED,
));
// _DOC close [ADSET_CREATE_DEMOGRAPHIC_TARGETING_2]

$adset->deleteSelf();
