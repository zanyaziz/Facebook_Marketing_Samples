<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;

use FacebookAdsDoc\Helper\AdImageCreationHelper;
use FacebookAdsDoc\Helper\AdVideoCreationHelper;
use FacebookAdsDoc\Helper\ProductSetCreationHelper;
use FacebookAdsDoc\Helper\ProductCreationHelper;
use FacebookAdsTest\Config\Config;

/** @var Config $config */

$thumbnail_url = (new AdImageCreationHelper())->getUrl();
$video_id = (new AdVideoCreationHelper())->getId();
$page_id = $config->pageId;
$ad_account_id = $config->accountId;
$url = $config->appUrl;
$product_set_helper = new ProductSetCreationHelper();
$product_set_id = $product_set_helper->getId();
$product_catalog_id = $product_set_helper->getProductCatalogId();

$retailer_ids = array();
for ($id = 1; $id <= 8; $id++) {
  $retailer_ids[] = $id;
  (new ProductCreationHelper())
    ->setProductCatalogId($product_catalog_id)
    ->setRetailerId($id)
    ->getId();
}
list($retailer_id_1, $retailer_id_2, $retailer_id_3, $retailer_id_4) =
  array_slice($retailer_ids, 0, 4);

// _DOC oncall [khim]
// _DOC open [ADCREATIVE_CREATE_VIDEO_COLLECTION]
// _DOC vars [url:s, video_id, page_id, ad_account_id:s, retailer_id_1, retailer_id_2, retailer_id_3, retailer_id_4]
use FacebookAds\Object\AdAccount;
use FacebookAds\Object\AdCreative;
use FacebookAds\Object\AdCreativeObjectStorySpec;
use FacebookAds\Object\AdCreativeVideoData;
use FacebookAds\Object\Fields\AdCreativeFields;
use FacebookAds\Object\Fields\AdCreativeObjectStorySpecFields;
use FacebookAds\Object\Fields\AdCreativeVideoDataFields;

$video_data = new AdCreativeVideoData();
$video_data->setData(array(
  AdCreativeVideoDataFields::TITLE => 'My title',
  AdCreativeVideoDataFields::IMAGE_URL => $thumbnail_url,
  AdCreativeVideoDataFields::VIDEO_ID => $video_id,
  AdCreativeVideoDataFields::CALL_TO_ACTION => array(
    'type' => 'LEARN_MORE',
    'value' => array(
      'link' => $url,
      'link_format' => 'VIDEO_LPP'
    ),
  ),
  "retailer_item_ids" => array(
    $retailer_id_1,
    $retailer_id_2,
    $retailer_id_3,
    $retailer_id_4),
));

$object_story_spec = new AdCreativeObjectStorySpec();
$object_story_spec->setData(array(
  AdCreativeObjectStorySpecFields::PAGE_ID => $page_id,
  AdCreativeObjectStorySpecFields::VIDEO_DATA => $video_data,
));

$creative = (new AdAccount($ad_account_id))->createAdCreative(
  array(
    AdCreativeFields::ID,
    AdCreativeFields::NAME,
    AdCreativeFields::OBJECT_STORY_SPEC,
    AdCreativeFields::PRODUCT_SET_ID,
  ),
  array(
    AdCreativeFields::NAME => 'Collection Sample Video Creative',
    AdCreativeFields::OBJECT_STORY_SPEC => $object_story_spec,
    AdCreativeFields::PRODUCT_SET_ID => $product_set_id,
  ));
// _DOC close [ADCREATIVE_CREATE_VIDEO_COLLECTION]

$creative->deleteSelf();
