<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;

use FacebookAdsDoc\Helper\AdImageCreationHelper;
use FacebookAdsDoc\Helper\AdSetCreationHelper;
use FacebookAdsDoc\Helper\PageOfferCreationHelper;
use FacebookAdsTest\Config\Config;
/** @var Config $config */

$ad_account_id = $config->accountId;
$page_id = $config->pageId;
$image_hash = (new AdImageCreationHelper())->getHash();
$ad_set_id = (new AdSetCreationHelper())->getId();
$offer_id = (new PageOfferCreationHelper())->getId();
$offer_url = $config->appUrl;

// _DOC oncall [prestonlin]
// _DOC open [ADGROUP_CREATE_OFFER_CLAIMS]
// _DOC vars [ad_account_id:s, image_hash:s, ad_set_id, page_id, offer_id, offer_url:s]
use FacebookAds\Object\Ad;
use FacebookAds\Object\AdCreative;
use FacebookAds\Object\AdCreativeLinkData;
use FacebookAds\Object\AdCreativeObjectStorySpec;
use FacebookAds\Object\Fields\AdCreativeFields;
use FacebookAds\Object\Fields\AdCreativeLinkDataFields;
use FacebookAds\Object\Fields\AdCreativeObjectStorySpecFields;
use FacebookAds\Object\Fields\AdFields;

$link_data = new AdCreativeLinkData();
$link_data->setData(array(
  AdCreativeLinkDataFields::IMAGE_HASH => $image_hash,
  AdCreativeLinkDataFields::OFFER_ID => $offer_id,
  AdCreativeLinkDataFields::MESSAGE => 'Great Deal!',
  AdCreativeLinkDataFields::LINK => $offer_url,
));

$object_story_spec = new AdCreativeObjectStorySpec();
$object_story_spec->setData(array(
  AdCreativeObjectStorySpecFields::PAGE_ID => $page_id,
  AdCreativeObjectStorySpecFields::LINK_DATA => $link_data,
));

$creative = new AdCreative(null, $ad_account_id);
$creative->setData(array(
  AdCreativeFields::NAME => 'My Offer Ad Creative',
  AdCreativeFields::OBJECT_STORY_SPEC => $object_story_spec,
));

$ad = new Ad(null, $ad_account_id);
$ad->setData(array(
  AdFields::NAME => 'My Offer Ad',
  AdFields::ADSET_ID => $ad_set_id,
  AdFields::CREATIVE => $creative,
));
$ad->create();
// _DOC close [ADGROUP_CREATE_OFFER_CLAIMS]
$ad->deleteSelf();
