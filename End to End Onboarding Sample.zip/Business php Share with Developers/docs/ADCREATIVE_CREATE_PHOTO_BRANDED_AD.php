<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;

use FacebookAdsDoc\Helper\AdImageCreationHelper;
use FacebookAdsTest\Config\Config;

/** @var Config $config */

$image_hash = (new AdImageCreationHelper())->getHash();
$page_id = $config->pageId;
$sponsor_page_id = $config->secondaryPageId;
$ad_account_id = $config->accountId;

// _DOC oncall [clu]
// _DOC open [ADCREATIVE_CREATE_PHOTO_BRANDED_AD]
// _DOC vars [page_id, ad_account_id:s, image_hash:s, sponsor_page_id]
use FacebookAds\Object\AdCreative;
use FacebookAds\Object\AdCreativePhotoData;
use FacebookAds\Object\Fields\AdCreativePhotoDataFields;
use FacebookAds\Object\AdCreativeObjectStorySpec;
use FacebookAds\Object\Fields\AdCreativeObjectStorySpecFields;
use FacebookAds\Object\Fields\AdCreativeFields;

$photo_data = new AdCreativePhotoData();
$photo_data->setData(array(
  AdCreativePhotoDataFields::IMAGE_HASH => $image_hash,
  AdCreativePhotoDataFields::BRANDED_CONTENT_SPONSOR_PAGE_ID =>
    $sponsor_page_id,
));

$object_story_spec = new AdCreativeObjectStorySpec();
$object_story_spec->setData(array(
  AdCreativeObjectStorySpecFields::PAGE_ID => $page_id,
  AdCreativeObjectStorySpecFields::PHOTO_DATA => $photo_data,
));

$creative = new AdCreative(null, $ad_account_id);

$creative->setData(array(
  AdCreativeFields::NAME => 'Sample Creative',
  AdCreativeFields::OBJECT_STORY_SPEC => $object_story_spec,
));

$creative->create();
// _DOC close [ADCREATIVE_CREATE_PHOTO_BRANDED_AD]

$creative->deleteSelf();
