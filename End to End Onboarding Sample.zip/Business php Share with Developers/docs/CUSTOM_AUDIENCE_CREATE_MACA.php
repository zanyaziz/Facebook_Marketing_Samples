<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;

use FacebookAdsDoc\Helper\PromotableIosAppHelper;
use FacebookAdsTest\Config\Config;

/** @var Config $config */

$ad_account_id = $config->accountId;
$appHelper = new PromotableIosAppHelper();
$app_id = $appHelper->getAppId();

// this change is not atomic
// this test is likely to fail at the first run, wait few minutes and re-run
$event_name = 'fb_mobile_purchase';
$appHelper->assureCustomAppEvent($event_name);

// _DOC oncall [maggieshi]
// _DOC open [CUSTOM_AUDIENCE_CREATE_MACA]
// _DOC vars [ad_account_id:s, app_id]
use FacebookAds\Object\CustomAudience;
use FacebookAds\Object\Fields\CustomAudienceFields;
use FacebookAds\Object\Values\CustomAudienceSubtypes;

$custom_audience = new CustomAudience(null, $ad_account_id);
$custom_audience->setData(array(
  CustomAudienceFields::NAME => 'My Mobile App Custom Audience',
  CustomAudienceFields::SUBTYPE => CustomAudienceSubtypes::APP,
  CustomAudienceFields::RETENTION_DAYS => 15,
  CustomAudienceFields::RULE => array(
    '_application' => $app_id,
    '_eventName' => $event_name,
  ),
));
$custom_audience->create();
// _DOC close [CUSTOM_AUDIENCE_CREATE_MACA]

$custom_audience->deleteSelf();
