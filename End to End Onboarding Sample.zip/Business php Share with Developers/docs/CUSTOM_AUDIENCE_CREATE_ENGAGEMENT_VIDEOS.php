<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;

use FacebookAdsDoc\Helper\PageVideoCreationHelper;
use FacebookAdsTest\Config\Config;

/** @var Config $config */

$ad_account_id = $config->accountId;
$video_id_1 = (new PageVideoCreationHelper())->getId();
$video_id_2 = (new PageVideoCreationHelper())->getId();

// _DOC oncall [duliomatos]
// _DOC vars [ad_account_id:s, video_id_1, video_id_2]
// _DOC open [CUSTOM_AUDIENCE_CREATE_ENGAGEMENT_VIDEOS]
use FacebookAds\Object\CustomAudience;
use FacebookAds\Object\Fields\CustomAudienceFields;


$audience = new CustomAudience(null, $ad_account_id);
$audience->setData(array(
  CustomAudienceFields::NAME => 'Video Ads Engagement Audience',
  CustomAudienceFields::SUBTYPE => 'ENGAGEMENT',
  CustomAudienceFields::DESCRIPTION => 'Users who watched my video',
  CustomAudienceFields::PREFILL => true,
  CustomAudienceFields::RULE => array(
    array(
      'object_id' => $video_id_1,
      'event_name' => 'video_watched',
    ),
    array(
      'object_id' => $video_id_2,
      'event_name' => 'video_completed',
    ),
  ),
));

$audience->create();
// _DOC close [CUSTOM_AUDIENCE_CREATE_ENGAGEMENT_VIDEOS]

$audience->deleteSelf();
