<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */
namespace FacebookAdsDocs;

use FacebookAdsDoc\Helper\ProductCatalogCreationHelper;
use FacebookAds\Object\Fields\ProductCatalogFields;
use FacebookAds\Object\Values\ProductCatalogVerticalValues;
use FacebookAdsTest\Config\Config;

/** @var Config $config */

$product_catalog_id = (new ProductCatalogCreationHelper(array(
  ProductCatalogFields::VERTICAL => ProductCatalogVerticalValues::HOTELS,
)))->getId();

// _DOC oncall [ttho]
// _DOC open [HOTEL_CREATE]
// _DOC vars [product_catalog_id]
use FacebookAds\Object\Hotel;
use FacebookAds\Object\Fields\HotelFields;

$hotel = new Hotel(null, $product_catalog_id);

$hotel->setData(array(
  HotelFields::HOTEL_ID => 'h_1',
  HotelFields::NAME => 'Sample Hotel',
  HotelFields::DESCRIPTION => 'hotel description',
  HotelFields::BRAND => 'hotel brand',
  HotelFields::URL => 'http://www.example.com/samplehotel',
  HotelFields::IMAGES => array(
    array(
      'image_url' => 'http://www.example.com/pic1.jpg',
      'tags' => array('front view', 'balcony'),
    ),
    array(
      'image_url' => 'http://www.example.com/pic2.jpg',
      'tags' => array('lobby view'),
    ),
  ),
  HotelFields::ADDRESS => array(
    'street_address' => '1 Hacker Way',
    'city' => 'Menlo Park',
    'region' => 'California',
    'country' => 'United States',
    'postal_code' => '94025',
    'neighborhoods' => array('Palo Alto', 'Menlo Park'),
    'latitude' => 37.484116,
    'longitude' => -122.148244,
  ),
  HotelFields::GUEST_RATINGS => array(
    array(
      'score' => 7.8,
      'rating_system' => 'sample_rating',
      'number_of_raters' => 780,
    ),
  ),
  HotelFields::STAR_RATING => 4,
  HotelFields::PHONE => '+351234123456',
));

$hotel->create();
// _DOC close [HOTEL_CREATE]

$hotel->deleteSelf();
