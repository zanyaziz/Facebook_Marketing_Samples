<?php
/**
* Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
*
* You are hereby granted a non-exclusive, worldwide, royalty-free license to
* use, copy, modify, and distribute this software in source code or binary
* form for use in connection with the web services and APIs provided by
* Facebook.
*
* As with any software that integrates with the Facebook platform, your use
* of this software is subject to the Facebook Developer Principles and
* Policies [http://developers.facebook.com/policy/]. This copyright notice
* shall be included in all copies or substantial portions of the software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
* DEALINGS IN THE SOFTWARE.
*
*/

namespace FacebookAdsDocs;

use FacebookAdsDoc\Helper\AdsPixelHelper;
use FacebookAdsDoc\Helper\PageApiHelper;

$pixel_id = (new AdsPixelHelper())->getPixelId();

\FacebookAds\Api::setInstance((new PageApiHelper())->getApi());

// _DOC oncall [cph]
// _DOC open [PIXEL_GET_DACHECKS_WITH_CHECKS]
// _DOC vars [pixel_id]
use FacebookAds\Api;
use FacebookAds\Http\RequestInterface;

$data = Api::instance()->call(
  '/' . $pixel_id . '/da_checks',
  RequestInterface::METHOD_GET,
  array(
    'checks' => array(
      'pixel_decline',
      'pixel_missing_dpa_event',
      'pixel_missing_param_in_events',
      ),
  ))->getContent();
// _DOC close [PIXEL_GET_DACHECKS_WITH_CHECKS]
