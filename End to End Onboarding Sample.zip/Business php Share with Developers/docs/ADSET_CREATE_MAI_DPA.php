<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;

use FacebookAds\Object\Fields\CampaignFields;
use FacebookAds\Object\Values\CampaignObjectiveValues;
use FacebookAdsDoc\Helper\CampaignCreationHelper;
use FacebookAdsDoc\Helper\PromotableIosAppHelper;
use FacebookAdsDoc\Helper\ProductCatalogCreationHelper;
use FacebookAdsDoc\Helper\ProductSetCreationHelper;
use FacebookAdsDoc\Helper\ProductAudienceCreationHelper;
use FacebookAds\Object\Fields\ProductAudienceFields;
use FacebookAds\Object\Fields\ProductSetFields;
use FacebookAdsTest\Config\Config;

/** @var Config $config */

$ad_account_id = $config->accountId;
$app_helper = new PromotableIosAppHelper();
$app_id = $app_helper->getAppId();
$app_store_url = $app_helper->getUrl();
$product_catalog_id = (new ProductCatalogCreationHelper())->getId();
$product_set_id = (new ProductSetCreationHelper())
  ->setProductCatalogId($product_catalog_id)
  ->getObject()->{ProductSetFields::ID};
$product_audience_id = (new ProductAudienceCreationHelper())
  ->setProductSetId($product_set_id)
  ->getObject()->{ProductAudienceFields::ID};
$campaign_id = (new CampaignCreationHelper(array(
  CampaignFields::OBJECTIVE => CampaignObjectiveValues::MOBILE_APP_INSTALLS,
  CampaignFields::PROMOTED_OBJECT => array(
    'product_catalog_id' => $product_catalog_id,
  ),
)))->getId();

// _DOC oncall [ttho]
// _DOC open [ADSET_CREATE_MAI_DPA]
// _DOC vars [ad_account_id:s, campaign_id, app_id, app_store_url:s, product_audience_id, product_set_id]
use FacebookAds\Object\AdSet;
use FacebookAds\Object\Fields\AdSetFields;
use FacebookAds\Object\Fields\TargetingFields;
use FacebookAds\Object\Values\AdSetBillingEventValues;
use FacebookAds\Object\Values\AdSetOptimizationGoalValues;

$adset = new AdSet(null, $ad_account_id);

$adset->setData(array(
  AdSetFields::NAME => 'Mobile App Installs Ad Set with Dynamic Product Ads',
  AdSetFields::BID_AMOUNT => 3000,
  AdSetFields::BILLING_EVENT => AdSetBillingEventValues::IMPRESSIONS,
  AdSetFields::OPTIMIZATION_GOAL => AdSetOptimizationGoalValues::APP_INSTALLS,
  AdSetFields::DAILY_BUDGET => 15000,
  AdSetFields::CAMPAIGN_ID => $campaign_id,
  AdSetFields::TARGETING => array(
    TargetingFields::GEO_LOCATIONS => array(
      'countries' => array('US'),
    ),
    TargetingFields::PUBLISHER_PLATFORMS => array(
      'facebook',
      'audience_network',
    ),
    TargetingFields::DEVICE_PLATFORMS => array('mobile'),
    TargetingFields::USER_OS => array(
      'IOS',
    ),
    TargetingFields::DYNAMIC_AUDIENCE_IDS => array($product_audience_id),
  ),
  AdSetFields::PROMOTED_OBJECT => array(
    'product_set_id' => $product_set_id,
    'application_id' => $app_id,
    'object_store_url' => $app_store_url,
  ),
));

$adset->create(array(
  AdSet::STATUS_PARAM_NAME => AdSet::STATUS_PAUSED,
));
// _DOC close [ADSET_CREATE_MAI_DPA]

$adset->deleteSelf();
