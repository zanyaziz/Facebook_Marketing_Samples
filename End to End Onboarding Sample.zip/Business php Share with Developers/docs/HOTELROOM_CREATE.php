<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */
namespace FacebookAdsDocs;

use FacebookAdsDoc\Helper\HotelCreationHelper;
use FacebookAdsTest\Config\Config;

/** @var Config $config */

$hotel_id = (new HotelCreationHelper())->getId();

// _DOC oncall [ttho]
// _DOC open [HOTELROOM_CREATE]
// _DOC vars [hotel_id]
use FacebookAds\Object\HotelRoom;
use FacebookAds\Object\Fields\HotelRoomFields;

$hotelroom = new HotelRoom(null, $hotel_id);
$hotelroom->setData(array(
  HotelRoomFields::ROOM_ID => 'r_3',
  HotelRoomFields::NAME => 'Sample room type',
  HotelRoomFields::DESCRIPTION => 'room type description',
  HotelRoomFields::URL => 'http://www.example.com/sampleroom',
  HotelRoomFields::BASE_PRICE => '15900',
  HotelRoomFields::CURRENCY => 'USD',
  'pricing_variables' => array(
    array(
      'checkin_date' => (new \DateTime("+3 day"))->format('Y-m-d'),
      'nights' => 1,
      'price' => 170,
      'fees' => 10,
      'tax' => 14,
    ),
    array(
      'checkin_date' => (new \DateTime("+3 day"))->format('Y-m-d'),
      'nights' => 2,
      'price' => 330,
      'fees' => 10,
      'tax' => 20,
    ),
    array(
      'checkin_date' => (new \DateTime("+4 day"))->format('Y-m-d'),
      'nights' => 1,
      'price' => 160,
      'fees' => 10,
      'tax' => 13,
    ),
  ),
));

$hotelroom->create();
// _DOC close [HOTELROOM_CREATE]

$hotelroom->deleteSelf();
