<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;

use FacebookAdsDoc\Helper\CustomAudienceMultiKeyCreationHelper;
use FacebookAdsTest\Config\Config;

/** @var Config $config */

$custom_audience_id = (new CustomAudienceMultiKeyCreationHelper())->getId();
$app_id = $config->appId;

// _DOC oncall [pruno]
// _DOC open [CUSTOM_AUDIENCE_USERS_ADD_MULTIKEY_CROSS_PLATFORM]
// _DOC vars [custom_audience_id, app_id]
use FacebookAds\Api;
use FacebookAds\Http\RequestInterface;
use FacebookAds\Object\CustomAudienceNormalizers\HashNormalizer;
use FacebookAds\Object\Fields\CustomAudienceMultikeySchemaFields;

$schema = array(
  CustomAudienceMultikeySchemaFields::EMAIL,
  CustomAudienceMultikeySchemaFields::MADID,
  CustomAudienceMultikeySchemaFields::FB_USER_ID,
);

$users = array(
  array(
    'user1@example.com',
    '1234567890',
    '6032d997-3ab0-4de0-aa16-8af0e5b482fb',
  ),
  array(
    'user2@example.com',
    '',
    'B67385F8-9A82-4670-8C0A-6F9EA7513F5F',
  ),
  array(
    'user3@example.com',
    '9876543210',
    '',
  ),
);

foreach ($users as &$user) {
  $user[0] = hash(HashNormalizer::HASH_TYPE_SHA256, $user[0]);
}

$params = array(
  'payload' => array(
    'schema' => $schema,
    'app_ids' => array($app_id),
    'data' => $users,
  ),
);

Api::instance()->call(
  "/{$custom_audience_id}/users",
  RequestInterface::METHOD_POST,
  $params);
// _DOC close [CUSTOM_AUDIENCE_USERS_ADD_MULTIKEY_CROSS_PLATFORM]
