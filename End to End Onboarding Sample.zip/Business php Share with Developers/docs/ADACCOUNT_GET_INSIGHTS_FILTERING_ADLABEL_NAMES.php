<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;

use FacebookAdsTest\Config\Config;

/** @var Config $config */

$ad_account_id = $config->accountId;

// Not required to exist as a label
$ad_label_name = $config->testRunId;

// _DOC oncall [mmg]
// _DOC open [ADACCOUNT_GET_INSIGHTS_FILTERING_ADLABEL_NAMES]
// _DOC vars [ad_account_id:s, ad_label_name:s]
use FacebookAds\Object\AdAccount;
use FacebookAds\Object\Fields\AdsInsightsFields;
use FacebookAds\Object\Values\AdsInsightsLevelValues;
use FacebookAds\Object\Values\InsightsOperators;
$account = new AdAccount($ad_account_id);

$params = array(
  'level' => AdsInsightsLevelValues::AD,
  'filtering' => array(
    array(
      'field' => 'adgroup.adlabels',
      'operator' => InsightsOperators::ANY,
      'value' => array($ad_label_name),
    ),
  ),
  'time_range' => array(
    'since' => '2015-03-01',
    'until' => '2015-03-31',
  ),
);

$fields = array(
  AdsInsightsFields::INLINE_LINK_CLICKS,
  AdsInsightsFields::COST_PER_INLINE_LINK_CLICK,
  AdsInsightsFields::TOTAL_ACTIONS,
);

$stats = $account->getInsights($fields, $params);
// _DOC close [ADACCOUNT_GET_INSIGHTS_FILTERING_ADLABEL_NAMES]
