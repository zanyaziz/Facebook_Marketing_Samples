<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;

use FacebookAdsDoc\Helper\AdImageCreationHelper;
use FacebookAdsDoc\Helper\AdVideoCreationHelper;
use FacebookAdsDoc\Helper\PromotableIosAppHelper;
use FacebookAdsTest\Config\Config;

/** @var Config $config */

$ad_account_id = $config->accountId;
$page_id = $config->pageId;
$app_store_url = (new PromotableIosAppHelper())->getUrl();
$video_id = (new AdVideoCreationHelper())->getId();
$thumbnail_url = (new AdImageCreationHelper())->getUrl();

// _DOC oncall [pruno]
// _DOC open [ADCREATIVE_CREATE_MAIA_VIDEO]
// _DOC vars [video_id, thumbnail_url:s, app_store_url:s, page_id, ad_account_id:s]
use FacebookAds\Object\AdCreative;
use FacebookAds\Object\Fields\AdCreativeFields;
use FacebookAds\Object\Fields\AdCreativeVideoDataFields;
use FacebookAds\Object\Fields\AdCreativeObjectStorySpecFields;
use FacebookAds\Object\AdCreativeVideoData;
use FacebookAds\Object\AdCreativeObjectStorySpec;

$video_data = new AdCreativeVideoData();
$video_data->setData(array(
  AdCreativeVideoDataFields::VIDEO_ID => $video_id,
  AdCreativeVideoDataFields::IMAGE_URL => $thumbnail_url,
  AdCreativeVideoDataFields::CALL_TO_ACTION => array(
    'type' => 'INSTALL_MOBILE_APP',
    'value' => array(
      'link' => $app_store_url,
    ),
  ),
));

$story = new AdCreativeObjectStorySpec();
$story->setData(array(
  AdCreativeObjectStorySpecFields::PAGE_ID => $page_id,
  AdCreativeObjectStorySpecFields::VIDEO_DATA => $video_data,
));

$creative = new AdCreative(null, $ad_account_id);
$creative->setData(array(
  AdCreativeFields::OBJECT_STORY_SPEC => $story,
));
$creative->create();
// _DOC close [ADCREATIVE_CREATE_MAIA_VIDEO]

$creative->deleteSelf();
