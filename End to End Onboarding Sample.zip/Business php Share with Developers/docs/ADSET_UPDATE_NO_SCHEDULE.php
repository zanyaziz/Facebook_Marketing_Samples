<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;

use FacebookAdsDoc\Helper\AdSetCreationHelper;
use FacebookAdsTest\Config\Config;

/** @var Config $config */

$ad_set_id = (new AdSetCreationHelper(array(
  \FacebookAds\Object\Fields\AdSetFields::DAILY_BUDGET => null,
  \FacebookAds\Object\Fields\AdSetFields::LIFETIME_BUDGET => 100000,
  \FacebookAds\Object\Fields\AdSetFields::END_TIME
    => (new \DateTime("+1 week"))->format(\DateTime::ISO8601),
  \FacebookAds\Object\Fields\AdSetFields::PACING_TYPE => array('day_parting'),
  \FacebookAds\Object\Fields\AdSetFields::ADSET_SCHEDULE => array(
    array(
      'start_minute' => 720,
      'end_minute' => 840,
      'days' => array(1, 2, 3, 4, 5),
    ),
  ),
)))->getId();

// _DOC oncall [pruno]
// _DOC open [ADSET_UPDATE_NO_SCHEDULE]
// _DOC vars [ad_set_id]
use FacebookAds\Object\AdSet;
use FacebookAds\Object\Fields\AdSetFields;

$adset = new AdSet($ad_set_id);

$adset->setData(array(
  AdSetFields::PACING_TYPE => array('standard'),
  AdSetFields::ADSET_SCHEDULE => array(),
));
$adset->update();
// _DOC close [ADSET_UPDATE_NO_SCHEDULE]
