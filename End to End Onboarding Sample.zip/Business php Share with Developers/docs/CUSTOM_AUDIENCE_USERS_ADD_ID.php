<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 * * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;

use FacebookAdsDoc\Helper\CustomAudienceHelper;
use FacebookAdsTest\Config\Config;

/** @var Config $config */

$application_id = $config->appId;
$custom_audience_id = (new CustomAudienceHelper())->getId();
$user_id_1 = 1234;
$user_id_2 = 12345;

// _DOC oncall [paulbain]
// _DOC open [CUSTOM_AUDIENCE_USERS_ADD_ID]
// _DOC vars [custom_audience_id, application_id, user_id_1, user_id_2]
use FacebookAds\Object\CustomAudience;
use FacebookAds\Object\Values\CustomAudienceTypes;

// Add Facebook IDs of users of certain applications
$audience = new CustomAudience($custom_audience_id);
$audience->addUsers(
  array($user_id_1, $user_id_2),
  CustomAudienceTypes::ID,
  array($application_id));
// _DOC close [CUSTOM_AUDIENCE_USERS_ADD_ID]

$audience->deleteSelf();
