<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;

use FacebookAdsDoc\Helper\AdImageCreationHelper;
use FacebookAdsDoc\Helper\AdVideoCreationHelper;
use FacebookAdsTest\Config\Config;

/** @var Config $config */

$image_hash = (new AdImageCreationHelper())->getHash();
$video_id = (new AdVideoCreationHelper())->getId();
$url = $config->appUrl;
$page_id = $config->pageId;
$ad_account_id = $config->accountId;

// _DOC oncall [ttho]
// _DOC open [ADCREATIVE_CREATE_MULTI_PRODUCT_AD]
// _DOC vars [image_hash:s, video_id:s, url:s, page_id, ad_account_id:s]
use FacebookAds\Object\AdCreative;
use FacebookAds\Object\Fields\AdCreativeFields;
use FacebookAds\Object\Fields\AdCreativeLinkDataFields;
use FacebookAds\Object\Fields\AdCreativeObjectStorySpecFields;
use FacebookAds\Object\Fields\AdCreativeLinkDataChildAttachmentFields;
use FacebookAds\Object\AdCreativeLinkDataChildAttachment;
use FacebookAds\Object\AdCreativeLinkData;
use FacebookAds\Object\AdCreativeObjectStorySpec;

$product1 = (new AdCreativeLinkDataChildAttachment())->setData(array(
  AdCreativeLinkDataChildAttachmentFields::LINK =>
    'https://www.link.com/product1',
  AdCreativeLinkDataChildAttachmentFields::NAME => 'Product 1',
  AdCreativeLinkDataChildAttachmentFields::DESCRIPTION => '$8.99',
  AdCreativeLinkDataChildAttachmentFields::IMAGE_HASH => $image_hash,
  AdCreativeLinkDataChildAttachmentFields::VIDEO_ID => $video_id,
));

$product2 = (new AdCreativeLinkDataChildAttachment())->setData(array(
  AdCreativeLinkDataChildAttachmentFields::LINK =>
    'https://www.link.com/product2',
  AdCreativeLinkDataChildAttachmentFields::NAME => 'Product 2',
  AdCreativeLinkDataChildAttachmentFields::DESCRIPTION => '$9.99',
  AdCreativeLinkDataChildAttachmentFields::IMAGE_HASH => $image_hash,
  AdCreativeLinkDataChildAttachmentFields::VIDEO_ID => $video_id,
));

$product3 = (new AdCreativeLinkDataChildAttachment())->setData(array(
  AdCreativeLinkDataChildAttachmentFields::LINK =>
    'https://www.link.com/product3',
  AdCreativeLinkDataChildAttachmentFields::NAME => 'Product 3',
  AdCreativeLinkDataChildAttachmentFields::DESCRIPTION => '$10.99',
  AdCreativeLinkDataChildAttachmentFields::IMAGE_HASH => $image_hash,
));

$link_data = new AdCreativeLinkData();
$link_data->setData(array(
  AdCreativeLinkDataFields::LINK => $url,
  AdCreativeLinkDataFields::CHILD_ATTACHMENTS => array(
    $product1, $product2, $product3,
  ),
));

$object_story_spec = new AdCreativeObjectStorySpec();
$object_story_spec->setData(array(
  AdCreativeObjectStorySpecFields::PAGE_ID => $page_id,
  AdCreativeObjectStorySpecFields::LINK_DATA => $link_data,
));

$creative = new AdCreative(null, $ad_account_id);
$creative->setData(array(
  AdCreativeFields::NAME => 'Sample Creative',
  AdCreativeFields::OBJECT_STORY_SPEC => $object_story_spec,
));

$creative->create();
// _DOC close [ADCREATIVE_CREATE_MULTI_PRODUCT_AD]

$creative->deleteSelf();
