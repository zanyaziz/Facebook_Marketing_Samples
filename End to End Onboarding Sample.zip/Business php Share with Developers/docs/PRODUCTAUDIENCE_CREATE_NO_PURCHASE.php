<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;


use FacebookAdsDoc\Helper\ProductSetCreationHelper;
use FacebookAdsTest\Config\Config;

/** @var Config $config */

$ad_account_id = $config->accountId;
$product_set_id = (new ProductSetCreationHelper())->getId();

// _DOC oncall [pruno]
// _DOC open [PRODUCTAUDIENCE_CREATE_NO_PURCHASE]
// _DOC vars [ad_account_id:s, product_set_id]
use FacebookAds\Object\Fields\ProductAudienceFields;
use FacebookAds\Object\ProductAudience;

$product_audience = new ProductAudience(null, $ad_account_id);
$product_audience->setData(array(
  ProductAudienceFields::NAME => 'Product audience',
  ProductAudienceFields::PRODUCT_SET_ID => $product_set_id,
  ProductAudienceFields::INCLUSIONS => array(
    array(
      'retention_seconds' => 86400,
      'rule' => array(
        'event' => array('eq' => 'AddToCart'),
      ),
    ),
    array(
      'retention_seconds' => 72000,
      'rule' => array(
        'event' => array('eq' => 'ViewContent'),
      ),
    ),
  ),
  ProductAudienceFields::EXCLUSIONS => array(
    array(
      'retention_seconds' => 172800,
      'rule' => array(
        'event' => array('eq' => 'Purchase'),
      ),
    ),
  ),
));
$product_audience->create();
// _DOC close [PRODUCTAUDIENCE_CREATE_NO_PURCHASE]

$product_audience->deleteSelf();
