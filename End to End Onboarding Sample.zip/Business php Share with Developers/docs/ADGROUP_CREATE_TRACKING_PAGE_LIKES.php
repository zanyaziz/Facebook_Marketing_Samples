<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;

use FacebookAdsDoc\Helper\AdSetCreationHelper;
use FacebookAdsDoc\Helper\PostCreationHelper;
use FacebookAdsTest\Config\Config;

/** @var Config $config */

$ad_account_id = $config->accountId;
$page_id = $config->pageId;
$ad_set_id = (new AdSetCreationHelper())->getId();
$post_id = (new PostCreationHelper())->getId();

// _DOC oncall [mmg]
// _DOC open [ADGROUP_CREATE_TRACKING_PAGE_LIKES]
// _DOC vars [ad_set_id, page_id, ad_account_id:s, post_id]
use FacebookAds\Object\Ad;
use FacebookAds\Object\Fields\AdFields;

$fields = array(
  AdFields::NAME => 'test',
  AdFields::ADSET_ID => $ad_set_id,
  AdFields::CREATIVE => array(
    'object_story_id' => $post_id,
  ),
  AdFields::TRACKING_SPECS => array(
    'action.type' => 'like',
    'page' => $page_id,
  ),
);

$ad = new Ad(null, $ad_account_id);
$ad->create($fields);
// _DOC close [ADGROUP_CREATE_TRACKING_PAGE_LIKES]

$ad->deleteSelf();
