<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;

use FacebookAdsDoc\Helper\AdsPixelHelper;
use FacebookAdsDoc\Helper\ProductCatalogCreationHelper;
use FacebookAdsTest\Config\Config;

/** @var Config $config */

$product_catalog_id = (new ProductCatalogCreationHelper())->getId();
$pixel_id = (new AdsPixelHelper())->getPixelId();
$app_id = $config->appId;

// _DOC oncall [pruno]
// _DOC open [PRODUCTCATALOG_ADD_EXTERNAL_EVENT_SOURCES]
// _DOC vars [product_catalog_id, pixel_id, app_id]
use FacebookAds\Object\ProductCatalog;

$product_catalog = new ProductCatalog($product_catalog_id);
$product_catalog->createExternalEventSource(array(), array(
  'external_event_sources' => array(
    $pixel_id,
    $app_id,
  ),
));
// _DOC close [PRODUCTCATALOG_ADD_EXTERNAL_EVENT_SOURCES]
