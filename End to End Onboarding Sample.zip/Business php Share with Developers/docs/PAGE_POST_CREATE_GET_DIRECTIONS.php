<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;

use FacebookAds\Object\Values\AdCreativeCallToActionTypeValues;
use FacebookAdsDoc\Helper\AdImageCreationHelper;
use FacebookAdsDoc\Helper\PageApiHelper;
use FacebookAdsDocsmith\Test\DocsmithTestTrait;
use FacebookAdsTest\Config\Config;

/** @var DocsmithTestTrait $test */
/** @var Config $config */

$page_id = $config->pageId;
$image_url = (new AdImageCreationHelper())->getUrl();

\FacebookAds\Api::setInstance((new PageApiHelper())->getApi());

// DPPP doesn't process substrings, only scoped vars
$test->mockCurlVariableIfHttpMocked($page_id, 'page_id');

// _DOC oncall [pruno]
// _DOC open [PAGE_POST_CREATE_GET_DIRECTIONS]
// _DOC vars [image_url:s, page_id]
use FacebookAds\Api;
use FacebookAds\Http\RequestInterface;

$params = array(
  'message' => 'Come check out our new store in Menlo Park!',
  'link' => 'https://www.facebook.com/'.$page_id,
  'picture' => $image_url,
  'published' => 0,
  'call_to_action' => array(
    'type' => AdCreativeCallToActionTypeValues::GET_DIRECTIONS,
    'value' => array(
      'link' => 'fbgeo://37.48327, -122.15033, "1601 Willow Rd Menlo Park CA"',
    ),
  ),
);

$data = Api::instance()->call(
  '/'.$page_id.'/feed',
  RequestInterface::METHOD_POST,
  $params)->getContent();
// _DOC close [PAGE_POST_CREATE_GET_DIRECTIONS]

Api::instance()->call('/'.$data['id'], RequestInterface::METHOD_DELETE);
