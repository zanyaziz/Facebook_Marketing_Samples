<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;

use FacebookAdsDoc\Helper\AdImageCreationHelper;

use FacebookAdsDoc\Helper\PromotableIosAppHelper;
use FacebookAdsTest\Config\Config;

/** @var Config $config */
$page_id = $config->pageId;
$app_store_url = (new PromotableIosAppHelper())->getUrl();
$image_hash = (new AdImageCreationHelper())->getHash();
$ad_account_id = $config->accountId;
$deep_link_i = 'fb'.$config->appId.'://';
$link_title_i = 'link_title';

// _DOC oncall [yinshiz]
// _DOC open [ADCREATIVE_CREATE_CAROUSEL_CALL_TO_ACTION_APP_INSTALL]
// _DOC vars [ad_account_id:s, page_id, app_store_url:s, image_hash:s, deep_link_i:s, link_title_i:s]

use FacebookAds\Object\AdCreative;
use FacebookAds\Object\Fields\AdCreativeFields;
use FacebookAds\Object\Fields\AdCreativeObjectStorySpecFields;
use FacebookAds\Object\Fields\AdCreativeLinkDataFields;
use FacebookAds\Object\Fields\AdCreativeLinkDataChildAttachmentFields;

$child_attachments = array();

for ($i = 0; $i <= 3; $i++) {
  $child_attachments[] = array(
    AdCreativeLinkDataChildAttachmentFields::LINK => $app_store_url,
    AdCreativeLinkDataChildAttachmentFields::IMAGE_HASH => $image_hash,
    AdCreativeLinkDataChildAttachmentFields::CALL_TO_ACTION => array(
      'type' => 'USE_MOBILE_APP',
      'value' => array(
        'app_link' => $deep_link_i,
        'link_title' => $link_title_i,
      ),
    ),
  );
}

$object_story_spec = array(
  AdCreativeObjectStorySpecFields::PAGE_ID => $page_id,
  AdCreativeObjectStorySpecFields::LINK_DATA => array(
    AdCreativeLinkDataFields::MESSAGE => 'My description',
    AdCreativeLinkDataFields::LINK => $app_store_url,
    AdCreativeLinkDataFields::CAPTION => 'WWW.ITUNES.COM',
    AdCreativeLinkDataFields::CHILD_ATTACHMENTS => $child_attachments,
    AdCreativeLinkDataFields::MULTI_SHARE_OPTIMIZED => true,
  ),
);

$creative = new AdCreative(null, $ad_account_id);
$creative->setData(array(
  AdCreativeFields::NAME => 'Carousel app ad',
  AdCreativeFields::OBJECT_STORY_SPEC => $object_story_spec,
));

$creative->create();
// _DOC close [ADCREATIVE_CREATE_CAROUSEL_CALL_TO_ACTION_APP_INSTALL]

$creative->deleteSelf();
