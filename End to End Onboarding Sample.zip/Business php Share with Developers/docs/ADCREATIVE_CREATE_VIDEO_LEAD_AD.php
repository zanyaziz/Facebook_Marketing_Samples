<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;

use FacebookAdsDoc\Helper\AdImageCreationHelper;
use FacebookAdsDoc\Helper\AdVideoCreationHelper;
use FacebookAdsDoc\Helper\LeadgenFormCreationHelper;
use FacebookAdsTest\Config\Config;

/** @var Config $config */

$thumbnail_url = (new AdImageCreationHelper())->getUrl();
$video_id = (new AdVideoCreationHelper())->getId();
$page_id = $config->pageId;
$ad_account_id = $config->accountId;
$form_id = (new LeadgenFormCreationHelper())->getId();

// _DOC oncall [clu]
// _DOC open [ADCREATIVE_CREATE_VIDEO_LEAD_AD]
// _DOC vars [thumbnail_url:s, video_id, page_id, ad_account_id:s, form_id]
use FacebookAds\Object\AdCreative;
use FacebookAds\Object\AdCreativeVideoData;
use FacebookAds\Object\Fields\AdCreativeVideoDataFields;
use FacebookAds\Object\AdCreativeObjectStorySpec;
use FacebookAds\Object\Fields\AdCreativeObjectStorySpecFields;
use FacebookAds\Object\Fields\AdCreativeFields;
use FacebookAds\Object\Values\AdCreativeCallToActionTypeValues;

$video_data = new AdCreativeVideoData();
$video_data->setData(array(
  AdCreativeVideoDataFields::LINK_DESCRIPTION => 'try it out',
  AdCreativeVideoDataFields::IMAGE_URL => $thumbnail_url,
  AdCreativeVideoDataFields::VIDEO_ID => $video_id,
  AdCreativeVideoDataFields::CALL_TO_ACTION => array(
    'type' => AdCreativeCallToActionTypeValues::SIGN_UP,
    'value' => array(
      'link' => 'http://fb.me/',
      'lead_gen_form_id' => $form_id,
    ),
  ),
));

$object_story_spec = new AdCreativeObjectStorySpec();
$object_story_spec->setData(array(
  AdCreativeObjectStorySpecFields::PAGE_ID => $page_id,
  AdCreativeObjectStorySpecFields::VIDEO_DATA => $video_data,
));

$creative = new AdCreative(null, $ad_account_id);

$creative->setData(array(
  AdCreativeFields::OBJECT_STORY_SPEC => $object_story_spec,
));

$creative->create();
// _DOC close [ADCREATIVE_CREATE_VIDEO_LEAD_AD]

$creative->deleteSelf();
