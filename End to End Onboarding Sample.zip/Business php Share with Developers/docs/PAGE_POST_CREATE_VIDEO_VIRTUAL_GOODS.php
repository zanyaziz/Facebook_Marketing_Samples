<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocs;

use FacebookAdsDoc\Helper\AdVideoCreationHelper;
use FacebookAdsDoc\Helper\PageApiHelper;
use FacebookAdsDocsmith\Test\DocsmithTestTrait;
use FacebookAdsTest\Config\Config;

/** @var DocsmithTestTrait $test */
/** @var Config $config */

$test->skipIfHttpNotMocked('A valid Open Graph product link url is required'
  .'to create virtual good page post for canvas app');

$page_id = $config->pageId;
$thumbnail_path = (new AdVideoCreationHelper())->getThumbnailUrl();
$video_path = $config->testVideoPath;
$product_link = $config->appUrl;
$app_url = $config->appUrl;

\FacebookAds\Api::setInstance((new PageApiHelper())->getApi());

// _DOC oncall [yinshiz]
// _DOC open [PAGE_POST_CREATE_VIDEO_VIRTUAL_GOODS]
// _DOC vars [page_id, video_path:s, thumbnail_path:s, product_link:s, app_url:s]
use FacebookAds\Api;
use FacebookAds\Http\RequestInterface;
use FacebookAds\Object\Values\AdCreativeCallToActionTypeValues;

$params = array(
  'name' => 'My Video',
  'message' => 'Buy coins now!',
  'thumbnail' => $thumbnail_path,
  'published' => 0,
  'call_to_action' => array(
    'type' => AdCreativeCallToActionTypeValues::BUY_NOW,
    'value' => array(
      'link' => $app_url,
      'product_link' => $product_link,
    ),
  ),
);

$request = Api::instance()->prepareRequest(
  '/'.$page_id.'/videos',
  RequestInterface::METHOD_POST,
  $params);

$request->setLastLevelDomain('graph-video');
$request->getFileParams()->offsetSet('source', $video_path);
$response = Api::instance()->executeRequest($request);

$data = $response->getContent();
// _DOC close [PAGE_POST_CREATE_VIDEO_VIRTUAL_GOODS]

Api::instance()->call('/'.$data['id'], RequestInterface::METHOD_DELETE);
