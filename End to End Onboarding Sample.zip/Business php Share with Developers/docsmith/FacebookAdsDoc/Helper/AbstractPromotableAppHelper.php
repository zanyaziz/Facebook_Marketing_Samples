<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDoc\Helper;

use FacebookAds\Api;
use FacebookAds\Http\RequestInterface;

abstract class AbstractPromotableAppHelper extends AbstractHelper {

  /**
   * @var int
   */
  protected $appId;

  /**
   * @var string|null
   */
  protected $url;

  /**
   * @param int|null $app_id
   */
  public function __construct($app_id = null) {
    $this->appId = $app_id;
  }

  /**
   * @return int
   */
  public function getAppId() {
    return $this->run()->appId;
  }

  /**
   * @return string
   */
  abstract protected function getStoreIndex();

  /**
   * @return string
   */
  public function getUrl() {
    return $this->run()->url;
  }

  /**
   * @param string $event_name
   * @param array $event_params
   */
  public function assureCustomAppEvent(
    $event_name,
    array $event_params = array()) {
    $path = sprintf('/%d/activities', $this->getAppId());
    $params = array(
      'event' => 'CUSTOM_APP_EVENTS',
      'advertiser_id' => '1111-1111-1111-1111',
      'advertiser_tracking_enabled' => true,
      'application_tracking_enabled' => true,
      'custom_events' => array(
        $event_params + array(
          '_eventName' => $event_name,
          '_logTime' => time(),
        ),
      ),
    );
    $this->getAnonymousApi()
      ->call($path, RequestInterface::METHOD_POST, $params);
  }

  protected function doRun() {
    $accountId = $this->getConfig()->accountId;
    $response = Api::instance()->call(
      '/'.$accountId.'/advertisable_applications',
      RequestInterface::METHOD_GET,
      array('fields' => 'object_store_urls'));
    $content = $response->getContent();
    $data = $content['data'];
    foreach ($data as $object) {
      if (
        array_key_exists('object_store_urls', $object)
        && array_key_exists('itunes', $object['object_store_urls'])
      ) {
        $this->appId = (int) $object['id'];
        $this->url = $object['object_store_urls']['itunes'];
        break;
      }
    }
  }

  protected function doStub() {
    $this->appId = $this->getConfig()->appId;
    $this->url = $this->getConfig()->appUrl;
  }
}
