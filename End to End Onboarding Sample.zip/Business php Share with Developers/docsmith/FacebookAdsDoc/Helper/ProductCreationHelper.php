<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDoc\Helper;

use FacebookAds\Object\Fields\ProductCatalogFields;
use FacebookAds\Object\ProductCatalog;
use FacebookAds\Object\ProductItem;
use FacebookAds\Object\Fields\ProductItemFields;

/**
 * @method Product getObject()
 */
final class ProductCreationHelper extends AbstractCreateObjectHelper {

  /**
   * @var ProductCatalog
   */
  protected $productCatalog;

  /**
   * @var int
   */
  protected $retailerId;

  /**
   * @param int $product_catalog_id
   * @return $this
   */
  public function setProductCatalogId($product_catalog_id) {
    $this->productCatalog = new ProductCatalog($product_catalog_id);

    return $this;
  }

  /**
   * @return int
   */
  public function getProductCatalogId() {
    if ($this->productCatalog === null) {
      $this->productCatalog = (new ProductCatalogCreationHelper())->getObject();
    }

    return $this->productCatalog->{ProductCatalogFields::ID};
  }

  /**
   * @param int $retailer_id
   * @return $this
   */
  public function setRetailerId($retailer_id) {
    $this->retailerId = $retailer_id;

    return $this;
  }

  /**
   * @return int
   */
  public function getRetailerId() {
    if ($this->retailerId === null) {
      $this->retailerId =
        sprintf('%s|%s', $this->getConfig()->testRunId, uniqid());
    }

    return $this->retailerId;
  }

  protected function doRun() {
    $product_catalog_id = $this->getProductCatalogId();

    $data = $this->enhanceData(array(
      ProductItemFields::RETAILER_ID => $this->getRetailerId(),
      ProductItemFields::AVAILABILITY => 'in stock',
      ProductItemFields::CONDITION => 'new',
      ProductItemFields::DESCRIPTION => 'product description',
      ProductItemFields::IMAGE_URL => 'http://www.example.com/pic1.jpg',
      ProductItemFields::PRICE => '100',
      ProductItemFields::BRAND => 'brand',
      ProductItemFields::CATEGORY => 'test category',
      ProductItemFields::CURRENCY => 'USD',
      ProductItemFields::NAME => 'test name',
      ProductItemFields::URL => sprintf('%s/%s',
        $this->getConfig()->appUrl,
        $this->getRetailerId()),
    ));

    $this->object = (new ProductItem(null, $product_catalog_id))
      ->setData($data)
      ->create();

    $this->registerObject($this->object);
  }
}
