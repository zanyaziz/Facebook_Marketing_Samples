<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDoc\Helper;

use FacebookAds\Object\AdSet;
use FacebookAds\Object\Campaign;
use FacebookAds\Object\Fields\AdSetFields;
use FacebookAds\Object\Fields\CampaignFields;
use FacebookAds\Object\Fields\TargetingFields;
use FacebookAds\Object\Targeting;
use FacebookAds\Object\Values\AdSetBillingEventValues;
use FacebookAds\Object\Values\AdSetOptimizationGoalValues;

/**
 * @method AdSet getObject()
 */
final class AdSetCreationHelper extends AbstractCreateObjectHelper {

  /**
   * @var Campaign
   */
  protected $campaign;

  /**
   * @param int $campaign_id
   * @return $this
   */
  public function setCampaignId($campaign_id) {
    $this->campaign = new Campaign($campaign_id);

    return $this;
  }

  /**
   * @return int
   */
  public function getCampaignId() {
    if ($this->campaign === null) {
      $this->campaign = (new CampaignCreationHelper())->getObject();
    }

    return $this->campaign->{CampaignFields::ID};
  }

  protected function doRun() {
    $data = $this->enhanceData(array(
      AdSetFields::NAME => $this->getConfig()->testRunId,
      AdSetFields::OPTIMIZATION_GOAL => AdSetOptimizationGoalValues::REACH,
      AdSetFields::BILLING_EVENT => AdSetBillingEventValues::IMPRESSIONS,
      AdSetFields::BID_AMOUNT => 20,
      AdSetFields::DAILY_BUDGET => 1000,
      AdSetFields::CAMPAIGN_ID => $this->getCampaignId(),
      AdSetFields::TARGETING => (new Targeting())->setData(array(
        TargetingFields::GEO_LOCATIONS => array(
          'countries' => array('US'),
        ),
      )),
    ));

    $this->object = (new AdSet(null, $this->getConfig()->accountId))
      ->setData($data)
      ->create(array(
        AdSet::STATUS_PARAM_NAME => AdSet::STATUS_PAUSED,
      ));

    $this->registerObject($this->object);
  }
}
