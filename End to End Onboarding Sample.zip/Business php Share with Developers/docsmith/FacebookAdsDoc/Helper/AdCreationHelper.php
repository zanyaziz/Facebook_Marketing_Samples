<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDoc\Helper;

use FacebookAds\Object\Ad;
use FacebookAds\Object\AdCreative;
use FacebookAds\Object\AdSet;
use FacebookAds\Object\Fields\AdCreativeFields;
use FacebookAds\Object\Fields\AdFields;
use FacebookAds\Object\Fields\AdSetFields;

/**
 * @method Ad getObject()
 */
final class AdCreationHelper extends AbstractCreateObjectHelper {

  /**
   * @var AdSet
   */
  protected $adset;

  /**
   * @var AdCreative
   */
  protected $creative;

  /**
   * @param int $adset_id
   * @return $this
   */
  public function setAdsetId($adset_id) {
    $this->adset = new AdSet($adset_id);

    return $this;
  }

  /**
   * @return int
   */
  public function getAdsetId() {
    if ($this->adset === null) {
      $this->adset = (new AdSetCreationHelper())->getObject();
    }

    return $this->adset->{AdSetFields::ID};
  }

  /**
   * @param int $ad_creative_id
   * @return $this
   */
  public function setAdCreativeId($ad_creative_id) {
    $this->creative = new AdCreative($ad_creative_id);

    return $this;
  }

  /**
   * @return int
   */
  public function getAdCreativeId() {
    if ($this->creative === null) {
      $this->creative = (new AdCreativeCreationHelper())->getObject();
    }

    return $this->creative->{AdCreativeFields::ID};
  }

  protected function doRun() {
    $data = $this->enhanceData(array(
      AdFields::NAME => $this->getConfig()->testRunId,
      AdFields::ADSET_ID => $this->getAdsetId(),
      AdFields::CREATIVE => array(
        'creative_id' => $this->getAdCreativeId(),
      ),
    ));

    $this->object = (new Ad(null, $this->getConfig()->accountId))
      ->setData($data)
      ->create(array(
        Ad::STATUS_PARAM_NAME => Ad::STATUS_PAUSED,
      ));

    $this->registerObject($this->object);
  }
}
