<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDoc\Helper;

use FacebookAds\Api;
use FacebookAds\Object\AdAccountUser;
use FacebookAds\Object\Fields\AdAccountUserFields;
use FacebookAds\Http\RequestInterface;

final class MeHelper extends AbstractHelper {

  /**
   * @var AdAccountUser
   */
  protected $object;

  /**
   * @var bool
   */
  protected $isSystemUser;

  /**
   * @return AdAccountUser
   */
  public function getObject() {
    return $this->run()->object;
  }

  /**
   * @return int
   */
  public function getId() {
    return $this->run()->object->{AdAccountUserFields::ID};
  }

  /**
   * @return bool
   */
  public function isSystemUser() {
    return $this->run()->isSystemUser;
  }

  protected function doRun() {
    $data = $this->getApi()->call(
      '/me',
      RequestInterface::METHOD_GET,
      array('fields' => 'last_name'))->getContent();
    // System users don't have a surname
    $this->isSystemUser = !array_key_exists('last_name', $data);
    $this->object = (new AdAccountUser($data[AdAccountUserFields::ID]));
  }

  protected function doStub() {
    $this->doRun();
    $this->isSystemUser = false;
  }
}
