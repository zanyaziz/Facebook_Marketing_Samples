<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDoc\Helper;

use FacebookAds\Object\Fields\ProductSetFields;
use FacebookAds\Object\Fields\ProductCatalogFields;
use FacebookAds\Object\ProductSet;
use FacebookAds\Object\ProductCatalog;

/**
 * @method ProductSet getObject()
 */
final class ProductSetCreationHelper extends AbstractCreateObjectHelper {

  /**
   * @var ProductCatalog
   */
  protected $productCatalog;

  /**
   * @param int $product_catalog_id
   * @return $this
   */
  public function setProductCatalogId($product_catalog_id) {
    $this->productCatalog = new ProductCatalog($product_catalog_id);

    return $this;
  }

  /**
   * @return int
   */
  public function getProductCatalogId() {
    if ($this->productCatalog === null) {
      $this->productCatalog = (new ProductCatalogCreationHelper())->getObject();
    }

    return $this->productCatalog->{ProductCatalogFields::ID};
  }

  protected function doRun() {
    $data = $this->enhanceData(array(
      ProductSetFields::NAME => $this->getConfig()->testRunId,
    ));

    $product_catalog_id = $this->getProductCatalogId();
    $this->object = (new ProductSet(null, $product_catalog_id))
      ->setData($data)
      ->create();

    $this->registerObject($this->object);
  }
}
