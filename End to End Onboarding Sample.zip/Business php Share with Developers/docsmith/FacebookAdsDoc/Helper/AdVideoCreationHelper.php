<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDoc\Helper;

use FacebookAds\Object\AdVideo;
use FacebookAds\Object\Fields\AdVideoFields;

/**
 * @method AdVideo getObject()
 */
final class AdVideoCreationHelper extends AbstractCreateObjectHelper {

  /**
   * @param AdVideo $video
   * @return string|null
   */
  private function getValidThumbnail(AdVideo $video) {
    $field = $video->{AdVideoFields::THUMBNAILS};
    if ($field === null || !array_key_exists('data', $field)) {
      return null;
    }

    $thumbnails = $field['data'];
    foreach ($thumbnails as $thumbnail) {
      $url = $thumbnail['uri'];
      if ($thumbnail['is_preferred'] && !preg_match('/\.gif$/', $url)) {
        return $url;
      }
    }

    return null;
  }

  /**
   * @return string
   * @throws \RuntimeException
   */
  public function getThumbnailUrl() {
    $thumbnail = $this->getValidThumbnail($this->getObject());
    if ($thumbnail === null) {
      throw new \RuntimeException(
        'No valid thumbnail for video '.$this->getId());
    }

    return $thumbnail;
  }

  protected function pretendWaitForThumbnails() {
    $this->object->{AdVideoFields::THUMBNAILS} = array(
      'data' => array(
        array(
          'is_preferred' => true,
          'uri' => $this->getConfig()->appUrl,
        ),
      ),
    );
  }

  protected function waitForThumbnails() {
    if ($this->getIsStubbed()) {
      $this->pretendWaitForThumbnails();
      return;
    }

    // While the API is atomic, video processing happens asyncronously
    // this cause some fields to not be ready in the API and certain operations
    // to fail, like calculating thumbnail resizing for video-post creatives
    $object = $this->object;
    if (!$object instanceof AdVideo) {
      throw new \InvalidArgumentException('Unexpected type');
    }
    while ($this->getValidThumbnail($object) === null) {
      sleep(1);
      $this->object->read(array(
        AdVideoFields::THUMBNAILS,
      ));
    }
  }

  protected function doRun() {
    $data = $this->enhanceData(array(
      AdVideoFields::SOURCE => $this->getConfig()->testVideoPath,
    ));

    $this->object = (new AdVideo(null, $this->getConfig()->accountId))
      ->setData($data)
      ->create();

    $this->registerObject($this->object);

    $this->waitForThumbnails();
  }
}
