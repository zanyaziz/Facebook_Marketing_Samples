<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDoc\Helper;

use FacebookAds\Object\Fields\ProductCatalogFields;
use FacebookAds\Object\Fields\HotelFields;
use FacebookAds\Object\Values\ProductCatalogVerticalValues;
use FacebookAds\Object\ProductCatalog;
use FacebookAds\Object\Hotel;

/**
 * @method ProductCatalog getObject()
 */
final class HotelCreationHelper extends AbstractCreateObjectHelper {

  protected function doRun() {
    $product_catalog_id = (new ProductCatalogCreationHelper(array(
      ProductCatalogFields::VERTICAL => ProductCatalogVerticalValues::HOTELS,
    )))->getId();

    $data = $this->enhanceData(array(
      HotelFields::HOTEL_ID => 'h_1',
      HotelFields::NAME => 'Sample Hotel',
      HotelFields::DESCRIPTION => 'hotel description',
      HotelFields::BRAND => 'hotel brand',
      HotelFields::URL => 'http://www.example.com/samplehotel',
      HotelFields::IMAGES => array(
        array(
          'image_url' => 'http://www.example.com/pic1.jpg',
          'tags' => array('front view'),
        ),
        array(
          'image_url' => 'http://www.example.com/pic2.jpg',
          'tags' => array('lobby view'),
        ),
      ),
      HotelFields::ADDRESS => array(
        'street_address' => '1 Hacker Way',
        'city' => 'Menlo Park',
        'region' => 'California',
        'country' => 'United States',
        'postal_code' => '94025',
        'neighborhoods' => array('Palo Alto', 'Menlo Park'),
        'latitude' => 37.484116,
        'longitude' => -122.148244,
      ),
      HotelFields::GUEST_RATINGS => array(
        array(
          'score' => 7.8,
          'rating_system' => 'sample_rating',
          'number_of_raters' => 780,
        ),
      ),
      HotelFields::STAR_RATING => 4,
      HotelFields::PHONE => '+351234123456',
    ));

    $this->object = (new Hotel(null, $product_catalog_id))
      ->setData($data)
      ->create();

    $this->registerObject($this->object);
  }
}
