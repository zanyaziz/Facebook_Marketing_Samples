<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDoc\Helper;

use FacebookAds\Object\AdAccount;
use FacebookAds\Object\AdsPixel;
use FacebookAds\Object\Fields\AdsPixelFields;

final class AdsPixelHelper extends AbstractHelper {

  /**
   * @var AdsPixel
   */
  protected $pixel;

  protected function doRun() {
    $ad_account_id = $this->getConfig()->accountId;
    $account = new AdAccount($ad_account_id);
    $pixels = $account->getAdsPixels(array(AdsPixelFields::CODE));

    if (!$pixels->count()) {
      $pixel = new AdsPixel(null, $ad_account_id);
      $pixel->{AdsPixelFields::NAME} = 'My WCA Pixel';
      $pixel->create();
    } else {
      $pixel = $pixels->current();
    }

    $pixel->sharePixelWithAdAccount(
      $this->getConfig()->businessId,
      (int) substr($this->getConfig()->accountId, 4));

    $this->pixel = $pixel;
  }

  /**
   * @return int
   */
  public function getPixelId() {
    return $this->run()->pixel->{AdsPixelFields::ID};
  }
}
