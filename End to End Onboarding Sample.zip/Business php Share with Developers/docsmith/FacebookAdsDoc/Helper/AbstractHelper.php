<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDoc\Helper;

use FacebookAds\AnonymousSession;
use FacebookAds\Api;
use FacebookAdsDocsmith\GraphGarbageCollector\GraphGarbageCollector;
use FacebookAdsDocsmith\Http\Adapter\RelayAdapter;
use FacebookAdsDocsmith\Runner;
use FacebookAdsDocsmith\Test\DocsmithTestTrait;
use FacebookAdsDocsmith\Test\GenCurlTest;
use FacebookAdsTest\AbstractTestCase;
use FacebookAdsTest\Config\Config;

abstract class AbstractHelper {

  /**
   * @var bool
   */
  private $didRun = false;

  /**
   * @var bool
   */
  private static $isStubbed = false;

  /**
   * @param bool $is_stubbed
   */
  public static function setIsStubbed($is_stubbed) {
    self::$isStubbed = $is_stubbed;
  }

  /**
   * @return bool
   */
  protected function getIsStubbed() {
    return self::$isStubbed;
  }

  /**
   * @param mixed $value
   * @return mixed
   */
  protected function than($value) {
    return $value;
  }

  /**
   * @return Runner
   */
  private function getRunner() {
    return Runner::getInstance();
  }

  /**
   * @return GraphGarbageCollector
   */
  protected function getGraphGarbageCollector() {
    return $this->getRunner()->getGraphGarbageCollector();
  }

  /**
   * @return AbstractTestCase|DocsmithTestTrait
   */
  protected function getCurrentTest() {
    return $this->getRunner()->getTestCase();
  }

  /**
   * @return Config
   */
  protected function getConfig() {
    return $this->getCurrentTest()->getConfig();
  }

  /**
   * @return string
   */
  protected function getUniqueTestRunId() {
    return $this->getConfig()->testRunId.'-'.uniqid();
  }

  /**
   * @return Api
   */
  protected function getApi() {
    return Api::instance();
  }

  /**
   * @return Api
   */
  protected function getAnonymousApi() {
    return $this->getApi()->getCopyWithSession(new AnonymousSession());
  }

  /**
   * @return int
   * @throws \RuntimeException
   */
  protected function getRelayUniqueId() {
    if (!$this->getIsStubbed()) {
      throw new \RuntimeException(
        'Trying to access the relay HTTP adapter when running agains prod');
    }

    /** @var GenCurlTest|DocsmithTestTrait $test */
    $test = $this->getCurrentTest();

    /** @var RelayAdapter $adapter */
    $adapter = $test->getHttpClient()->getAdapter();

    return $adapter->getUniqueId();
  }

  /**
   * @return void
   */
  abstract protected function doRun();

  /**
   * Override to provide a mock response in HTTP-Relay mode
   * @return void
   */
  protected function doStub() {
    $this->doRun();
  }

  /**
   * @return $this
   */
  protected function run() {
    if (!$this->didRun) {
      if ($this->getIsStubbed()) {
        $this->doStub();
      } else {
        $this->doRun();
      }
      $this->didRun = true;
    }

    return $this;
  }
}
