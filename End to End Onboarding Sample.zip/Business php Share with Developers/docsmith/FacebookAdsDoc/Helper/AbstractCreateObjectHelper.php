<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDoc\Helper;

use FacebookAds\Object\AbstractCrudObject;
use FacebookAdsDocsmith\GraphGarbageCollector\GenericDeletableObject;

abstract class AbstractCreateObjectHelper extends AbstractHelper {

  /**
   * @var array
   */
  protected $custom = array();

  /**
   * @var AbstractCrudObject|null
   */
  protected $object;

  /**
   * @param array $custom
   */
  public function __construct(array $custom = array()) {
    $this->custom = $custom;
  }

  /**
   * @param array $data
   * @return array
   */
  protected function enhanceData(array $data) {
    return $this->custom + $data;
  }

  /**
   * @param AbstractCrudObject $object
   * @return AbstractCrudObject
   */
  protected function registerObject(AbstractCrudObject $object) {
    $this->getGraphGarbageCollector()->register($object);

    return $object;
  }

  /**
   * @param int|string $object_id
   * @return AbstractCrudObject
   */
  protected function registerId($object_id) {
    return $this->registerObject(
      new GenericDeletableObject(
        is_numeric($object_id) ? (int) $object_id : $object_id));
  }

  /**
   * @return AbstractCrudObject
   */
  public function getObject() {
    return $this->run()->object;
  }

  /**
   * @return int
   */
  public function getId() {
    return $this->getObject()->{AbstractCrudObject::FIELD_ID};
  }
}
