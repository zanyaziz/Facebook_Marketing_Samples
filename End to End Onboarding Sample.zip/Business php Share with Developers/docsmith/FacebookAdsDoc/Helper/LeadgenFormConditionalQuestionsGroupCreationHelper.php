<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDoc\Helper;

use FacebookAds\Http\FileParameter;
use FacebookAds\Http\RequestInterface;

final class LeadgenFormConditionalQuestionsGroupCreationHelper
  extends AbstractCreateObjectHelper {

  use PageAwareTrait;

  protected function doRun() {
    $page_api = (new PageApiHelper())->setPageId($this->getPageId())->getApi();

    // FIXME do not hardcode path to static assets. Use \FacebookAdsTest\Config\Config
    $filename =
      __DIR__ . '/../../../test/misc/leadgen_conditional_questions_group.csv';

    $request = $page_api->prepareRequest(
      '/'.$this->getPageId().'/leadgen_conditional_questions_group',
      RequestInterface::METHOD_POST);

    $request->getFileParams()->offsetSet(
      'conditional_questions_group_csv',
      (new FileParameter($filename))->setMimeType("text/csv"));

    $data = $page_api->executeRequest($request)->getContent();
    $this->object = $this->registerId($data['id']);
  }
}
