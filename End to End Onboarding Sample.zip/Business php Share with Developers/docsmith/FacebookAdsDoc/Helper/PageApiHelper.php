<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDoc\Helper;

use FacebookAds\Api;
use FacebookAds\Session;

final class PageApiHelper extends AbstractHelper {
  use PageAwareTrait;

  /**
   * @var string
   */
  protected $accessToken;

  /**
   * @var Api
   */
  protected $api;

  /**
   * @return Api
   */
  public function getApi() {
    return $this->run()->api;
  }

  /**
   * @return Api
   */
  private function getUserApi() {
    return parent::getApi();
  }

  protected function initApi() {
    $page_session = new Session(
      $this->getConfig()->appId,
      $this->getConfig()->appSecret,
      $this->accessToken);

    $this->api = $this->getUserApi()->getCopyWithSession($page_session);
  }

  protected function doRun() {
    $data = $this->getUserApi()->call('/me/accounts')->getContent();

    $page_token = '';
    foreach ($data['data'] as $page) {
      if ($page['id'] == $this->getPageId()) {
        $page_token = $page['access_token'];
        break;
      }
    }
    if ($page_token === '') {
      throw new \InvalidArgumentException(
        'Page access token for the page id '
          .$this->getPageId().' cannot be found.'
      );
    }

    $this->accessToken = $page_token;
    $this->initApi();
  }

  protected function doStub() {
    $this->accessToken = $this->getRelayUniqueId();
    $this->initApi();
  }
}
