<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocsmith\GraphGarbageCollector;

use FacebookAds\Object\AbstractCrudObject;
use FacebookAdsDocsmith\ResultPrinter;

class GraphGarbageCollector {

  /**
   * @var int
   */
  const DEFAULT_PRIORITY = 1000;

  /**
   * @var ResultPrinter
   */
  protected $printer;

  /**
   * @var array
   */
  protected $registry = array();

  /**
   * @var array
   */
  protected $hashMap = array();

  /**
   * @param ResultPrinter $printer
   */
  public function __construct(ResultPrinter $printer) {
    $this->printer = $printer;
    $self = $this;

    register_shutdown_function(function() use ($self) {
      if ($this->count() > 0) {
        // On normal execution, Runner takes care of cleaning.
        // Runner also manages fatal erros, if the registry is not empty at
        // shutdown something really bad happend, possibly a framework issue
        $self->getPrinter()->writeError('GGC SHUTDOWN!'.PHP_EOL);
      }
      $self->clean();
    });
  }

  /**
   * @return ResultPrinter
   */
  public function getPrinter() {
    return $this->printer;
  }

  /**
   * @return int
   */
  public function count() {
    return count($this->hashMap);
  }

  /**
   * @param AbstractCrudObject $object
   * @return bool
   */
    public function isObjectRegistered(AbstractCrudObject $object) {
    return isset($this->hashMap[spl_object_hash($object)]);
  }

  /**
   * @param GraphGarbageCollectorObjectWrapper $wrapper
   */
  protected function addToRegistry(
    GraphGarbageCollectorObjectWrapper $wrapper) {

    if (!array_key_exists($wrapper->getPriority(), $this->registry)) {
      $this->registry[$wrapper->getPriority()] = array();
    }

    $this->registry[$wrapper->getPriority()][] = $wrapper;
  }

  /**
   * @param GraphGarbageCollectorObjectWrapper $wrapper
   */
  protected function removeFromRegistry(
    GraphGarbageCollectorObjectWrapper $wrapper) {

    if (!array_key_exists($wrapper->getPriority(), $this->registry)) {
      return;
    }

    if (array_key_exists(
      $wrapper->getHash(), $this->registry[$wrapper->getPriority()])) {

      unset($this->registry[$wrapper->getPriority()][$wrapper->getHash()]);
    }

    if (!count($this->registry[$wrapper->getPriority()])) {
      unset($this->registry[$wrapper->getPriority()]);
    }
  }

  /**
   * @return GraphGarbageCollectorObjectWrapper|null
   */
  protected function popFromRegistry() {
    if (!$this->registry) {
      return null;
    }

    $priority = max(array_keys($this->registry));
    $object = array_pop($this->registry[$priority]);
    unset($this->hashMap[$object->getHash()]);

    if (!count($this->registry[$priority])) {
      unset($this->registry[$priority]);
    }

    return $object;
  }

  /**
   * Register an object to be deleted whenever it becomes garbage or update
   * clean-up priority for an already registered object
   *
   * @param AbstractCrudObject $object
   * @param int $priority
   */
  public function register(
    AbstractCrudObject $object,
    $priority = GraphGarbageCollector::DEFAULT_PRIORITY) {

    $wrapper = new GraphGarbageCollectorObjectWrapper($object, $priority);
    if (isset($this->hashMap[$wrapper->getHash()])) {
      /** @var GraphGarbageCollectorObjectWrapper $old_wrapper */
      $old_wrapper = $this->hashMap[$wrapper->getHash()];
      if ($old_wrapper->getPriority() === $wrapper->getPriority()) {
        return;
      }
      $this->removeFromRegistry($old_wrapper);
    } else {
      $this->hashMap[$wrapper->getHash()] = $wrapper;
    }

    $this->addToRegistry($wrapper);
  }

  /**
   * @param AbstractCrudObject $object
   */
  public function free(AbstractCrudObject $object) {
    if (!isset($this->hashMap[spl_object_hash($object)])) {
      return;
    }

    $this->removeFromRegistry($this->hashMap[spl_object_hash($object)]);
    unset($this->hashMap[spl_object_hash($object)]);
  }

  public function clean() {
    while ($wrapper = $this->popFromRegistry()) {
      if (method_exists($wrapper->getObject(), 'deleteSelf')) {
        try {
          $wrapper->getObject()->deleteSelf();
        } catch (\Exception $e) {
          // Common exceptions are double deletes:
          // Object has been registered and also deleted in the example
        }
      }
    }
  }
}
