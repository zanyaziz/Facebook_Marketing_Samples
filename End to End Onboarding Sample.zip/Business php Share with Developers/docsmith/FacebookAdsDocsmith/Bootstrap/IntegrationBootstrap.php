<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocsmith\Bootstrap;

use FacebookAdsTest\Bootstrap\IntegrationBootstrap as TestIntegrationBootstrap;

class IntegrationBootstrap extends TestIntegrationBootstrap {

  /**
   * @return string[]
   */
  protected function getComposerAutoloadPathPriorityList() {
    $list = array(
      // Sandcastle composer install
      '/packages/ads_sdk.php/vendor/autoload.php',
      // Local composer install
      parent::getComposerAutoloadPath(),
    );

    if (array_key_exists('HOME', $_SERVER)) {
      // Global composer install
      $list[] = $_SERVER['HOME'].'/.composer/vendor/autoload.php';
    }

    return $list;
  }

  /**
   * @return string
   */
  protected function getComposerAutoloadPath() {
    foreach ($this->getComposerAutoloadPathPriorityList() as $path) {
      if (is_file($path) && is_readable($path)) {
        return $path;
      }
    }

    throw new \RuntimeException('No viable autoload found');
  }

  public function getAutoloader() {
    if ($this->autoloader === null) {
      $autoloader = parent::getAutoloader();
      $autoloader->addPsr4('FacebookAdsDocsmith\\', __DIR__ . '/../');
      $autoloader->addPsr4(
        'FacebookAdsDoc\\', __DIR__ . '/../../FacebookAdsDoc/');
      $autoloader->addPsr4(
        'FacebookAds\\', __DIR__ . '/../../../src/FacebookAds/');
    }

    return $this->autoloader;
  }
}
