<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocsmith;

class ResultPrinter extends \PHPUnit_TextUI_ResultPrinter {

  /**
   * @var resource|null
   */
  protected $resource;

  /**
   * @var string|null
   */
  protected $docFileath;

  /**
   * @var bool
   */
  protected $forceError = false;

  protected function printHeader() {}

  protected function printFooter(\PHPUnit_Framework_TestResult $result) {}

  protected function writeProgress($progress) {}

  public function flush() {}

  /**
   * @param string $doc_filepath
   */
  public function setDocFilepath($doc_filepath) {
    $this->docFileath = $doc_filepath;
  }

  /**
   * @return string|null
   */
  public function getDocFilepath() {
    return $this->docFileath;
  }

  /**
   * @param \PHPUnit_Framework_TestResult $result
   */
  public function printErrors(\PHPUnit_Framework_TestResult $result) {
    if ($result->errorCount() > 0) {
      $this->forceError = true;
      $this->write('While testing '.$this->getDocFilepath().PHP_EOL);
      parent::printErrors($result);
      $this->write(PHP_EOL.PHP_EOL);
      $this->forceError = false;
    }
  }

  /**
   * @param resource $resource
   */
  public function setResource($resource) {
    $this->resource = $resource;
  }

  /**
   * @return resource
   */
  public function getResource() {
    if ($this->resource === null) {
      $this->resource = STDOUT;
    }

    return $this->resource;
  }

  /**
   * @param string $buffer
   * @param resource $resource
   */
  protected function writeToResource($buffer, $resource) {
    fwrite($this->forceError ? STDERR : $resource, $buffer);
  }

  /**
   * @param string $buffer
   */
  public function write($buffer) {
    if (
      strpos($buffer, \PHPUnit_Runner_Version::getVersionString()) === false
    ) {
      $this->writeToResource($buffer, $this->getResource());
    }
  }

  /**
   * @param string $buffer
   */
  public function writeError($buffer) {
    $this->writeToResource($buffer, STDERR);
  }
}
