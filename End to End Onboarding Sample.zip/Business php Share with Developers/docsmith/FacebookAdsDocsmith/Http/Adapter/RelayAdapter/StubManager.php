<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocsmith\Http\Adapter\RelayAdapter;

use FacebookAds\Http\Client;
use FacebookAds\Http\RequestInterface;
use FacebookAdsDocsmith\Http\Adapter\RelayAdapter;
use FacebookAdsDocsmith\Http\Adapter\RelayAdapter\Stub\AdImageCreateStub;
use FacebookAdsDocsmith\Http\Adapter\RelayAdapter\Stub\AsyncJobCreateStub;
use FacebookAdsDocsmith\Http\Adapter\RelayAdapter\Stub\AsyncJobReadStub;
use FacebookAdsDocsmith\Http\Adapter\RelayAdapter\Stub\CatchAllStub;
use FacebookAdsDocsmith\Http\Adapter\RelayAdapter\Stub\EdgeGetStub;
use FacebookAdsDocsmith\Http\Adapter\RelayAdapter\Stub\ObjectCreateStub;
use FacebookAdsDocsmith\Http\Adapter\RelayAdapter\Stub\ObjectDeleteStub;
use FacebookAdsDocsmith\Http\Adapter\RelayAdapter\Stub\ObjectReadStub;
use FacebookAdsDocsmith\Http\Adapter\RelayAdapter\Stub\ObjectUpdateStub;
use FacebookAdsDocsmith\Http\Adapter\RelayAdapter\Stub\RateCardsGetStub;
use FacebookAdsDocsmith\Http\Adapter\RelayAdapter\Stub\StubInterface;
use FacebookAdsDocsmith\Http\Adapter\RelayAdapter\Stub\TargetingDescriptionReadStub;

class StubManager {

  /**
   * @var array
   */
  protected $stubs = array();

  /**
   * @var RelayAdapter
   */
  protected $adapter;

  /**
   * @param RelayAdapter $adapter
   * @return static
   */
  public static function factory(RelayAdapter $adapter) {
    return (new static($adapter->getClient()))->addStubs(array(
      new TargetingDescriptionReadStub($adapter),
      new RateCardsGetStub($adapter),
      new EdgeGetStub($adapter),
      new AsyncJobReadStub($adapter),
      new ObjectReadStub($adapter),
      new AdImageCreateStub($adapter),
      new AsyncJobCreateStub($adapter),
      new ObjectCreateStub($adapter),
      new ObjectUpdateStub($adapter),
      new ObjectDeleteStub($adapter),
      new CatchAllStub($adapter),
    ));
  }

  /**
   * @param Client $client
   */
  public function __construct(Client $client) {
    $this->client = $client;
  }

  /**
   * @return Client
   */
  public function getClient() {
    return $this->client;
  }

  /**
   * @return array
   */
  public function getStubs() {
    return $this->stubs;
  }

  /**
   * @param StubInterface $stub
   */
  public function addStub(StubInterface $stub) {
    array_push($this->stubs, $stub);
  }

  /**
   * @param array $stubs
   * @return $this
   */
  public function addStubs(array $stubs) {
    /** @var StubInterface $stub */
    foreach ($stubs as $stub) {
      $this->addStub($stub);
    }

    return $this;
  }

  /**
   * @param RequestInterface $request
   * @return mixed
   * @throws \DomainException
   */
  public function resolve(RequestInterface $request) {
    /** @var StubInterface $stub */
    foreach ($this->getStubs() as $stub) {
      if ($stub->matchRequest($request)) {
        return $stub->getResponseBody($request);
      }
    }

    throw new \DomainException('No stub can resolve request');
  }
}
