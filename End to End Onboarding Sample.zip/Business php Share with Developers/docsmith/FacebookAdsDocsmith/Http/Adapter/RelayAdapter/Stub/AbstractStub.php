<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocsmith\Http\Adapter\RelayAdapter\Stub;

use FacebookAds\Enum\AbstractEnum;
use FacebookAds\Enum\EmptyEnum;
use FacebookAds\Http\RequestInterface;
use FacebookAds\Object\AbstractCrudObject;
use FacebookAds\Object\AbstractObject;
use FacebookAdsDocsmith\Http\Adapter\RelayAdapter;

abstract class AbstractStub implements StubInterface {

  /**
   * @var RelayAdapter
   */
  protected $adapter;

  /**
   * @param RelayAdapter $adapter
   */
  public function __construct(RelayAdapter $adapter) {
    $this->adapter = $adapter;
  }

  /**
   * @return RelayAdapter
   */
  public function getAdapter() {
    return $this->adapter;
  }

  /**
   * @param RequestInterface $request
   * @return \ArrayObject
   */
  protected function getPathSegments(RequestInterface $request) {
    return new \ArrayObject(explode('/', trim($request->getPath(), '/')));
  }

  /**
   * @param RequestInterface $request
   * @return int
   */
  protected function countPathSegments(RequestInterface $request) {
    return $this->getPathSegments($request)->count();
  }

  /**
   * @param string $class
   * @param string $function
   * @return bool
   */
  protected function isFunctionCallInStackTrace($class, $function) {
    foreach (debug_backtrace(DEBUG_BACKTRACE_PROVIDE_OBJECT) as $call) {
      if (array_key_exists('object', $call)
        && is_a($call['object'], $class)
        && array_key_exists('function', $call)
        && $call['function'] === $function
      ) {
        return true;
      }
    }

    return false;
  }

  /**
   * @return AbstractCrudObject|null
   */
  protected function getCallingCrudObject() {
    foreach (debug_backtrace(DEBUG_BACKTRACE_PROVIDE_OBJECT) as $call) {
      if (array_key_exists('object', $call)
        && $call['object'] instanceof AbstractCrudObject
      ) {
        return $call['object'];
      }
    }

    return null;
  }

  /**
   * @param AbstractObject $object
   * @return array
   */
  protected function getObjectStub(AbstractObject $object) {
    return $object !== null
      ? $object->getFieldsEnum()->getValuesMap()
      : EmptyEnum::getInstance()->getValuesMap();
  }

  /**
   * @return AbstractEnum
   */
  protected function getCallingCrudObjectStub() {
    $object = $this->getCallingCrudObject();

    return $object !== null
      ? $object->getFieldsEnum()->getValuesMap()
      : EmptyEnum::getInstance()->getValuesMap();
  }
}
