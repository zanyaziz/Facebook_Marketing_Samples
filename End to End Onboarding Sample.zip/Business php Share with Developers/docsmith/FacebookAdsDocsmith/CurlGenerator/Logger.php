<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocsmith\CurlGenerator;

use FacebookAds\Http\FileParameter;
use FacebookAds\Http\Parameters;
use FacebookAds\Http\RequestInterface;
use FacebookAds\Logger\CurlLogger;
use FacebookAds\Object\AbstractObject;

class Logger extends CurlLogger {

  /**
   * @var string
   */
  const COMMENT_OPEN = '#';

  /**
   * @var string
   */
  const CURL_VARIABLE_SIGN = '%';

  /**
   * @var string
   */
  const PRODUCTION_TIER_DOMAIN = 'graph.facebook.com';

  /**
   * @var array
   */
  protected $placeholders = array();

  /**
   * @var \ArrayObject|null
   */
  protected $instructionIgnoreList;

  /**
   * @var \ArrayObject|null
   */
  protected $paramsIgnoreList;

  /**
   * @var \ArrayObject|null
   */
  protected $paramsEnforceList;

  /**
    * @return resource
    */
  public function getHandle() {
    return $this->handle;
  }

  /**
   * @param string $param_name
   * @param bool $is_file
   * @return string
   */
  public static function getPlaceholder($param_name, $is_file = false) {
    return ($is_file ? '@' : '').static::CURL_VARIABLE_SIGN.$param_name;
  }

  /**
   * @return \ArrayObject
   */
  public function getInstructionIgnoreList() {
    if ($this->instructionIgnoreList === null) {
      $this->instructionIgnoreList = new \ArrayObject();
    }

    return $this->instructionIgnoreList;
  }

  /**
   * @return \ArrayObject
   */
  public function getParamsIgnoreList() {
    if ($this->paramsIgnoreList === null) {
      $this->paramsIgnoreList = new \ArrayObject(array(
        'appsecret_proof',
      ));
    }

    return $this->paramsIgnoreList;
  }

  /**
   * @return \ArrayObject
   */
  public function getParamsEnforceList() {
    if ($this->paramsEnforceList === null) {
      $this->paramsEnforceList = new \ArrayObject(array(
        'access_token',
      ));
    }

    return $this->paramsEnforceList;
  }

  /**
   * @param string $arg
   * @param mixed $value
   */
  public function addPlaceholder($arg, $value) {
    $this->placeholders[$arg] = $value;
  }

  /**
   * @param mixed $value
   * @return string|null
   */
  public function getPlaceholderByValue($value) {
    if (is_scalar($value) && empty($value)) {
      // PHP empty values (eg: 0, '0', null, '')
      // can't be mocked due to loose comparison between scalars
      return null;
    }

    foreach ($this->placeholders as $varname => $value2) {
      // Disallow loose comparison between scalar and non-scalar (E_FATAL)
      // Disallow loose comparison between booleans and other scalars
      // Allow loose comparison between strings and numbers
      if (
        is_scalar($value) === is_scalar($value2)
        && is_bool($value) === is_bool($value2)
        && $value == $value2
      ) {
        return $varname;
      }
    }

    return null;
  }

  /**
   * @param string $buffer
   */
  protected function flush($buffer) {
    fwrite($this->getHandle(), $buffer."\n");
  }

  /**
   * @param array $argv
   * @return string
   */
  protected function serializeInstructionArgv(array $argv) {
    foreach ($argv as &$arg) {
      $arg = preg_replace('/:s$/', '', $arg);
    }

    return count($argv) > 0 ? '['.implode(', ', $argv).']' : '';
  }


  /**
   * @param $instruction_type
   * @param array $argv
   */
  protected function instructPassthru($instruction_type, array $argv) {
    $buffer = sprintf(
      '%s _DOC %s %s',
      static::COMMENT_OPEN,
      $instruction_type,
      $this->serializeInstructionArgv($argv));

    $this->flush($buffer);
  }

  /**
   * @param array|\Traversable $variable
   * @param bool $is_file
   * @return array|\Traversable
   */
  protected function anonymizeTraversable($variable, $is_file) {
    foreach ($variable as $key => $param) {
      $variable[$key] = $this->anonymize($param, $is_file);
    }

    return $variable;
  }

  /**
   * @param Object $variable
   * @param bool $is_file
   * @return Object|string
   */
  protected function anonymizeObject($variable, $is_file) {
    if ($is_file && $variable instanceof FileParameter) {
      return $this->normalizeFileParam($variable);
    }
    foreach (get_object_vars($variable) as $param_name) {
      $variable->{$param_name}
        = $this->anonymize($variable->{$param_name}, $is_file);
    }

    return $variable;
  }

  /**
   * @param FileParameter $file_param
   * @return string
   */
  protected function normalizeFileParam(FileParameter $file_param) {
    return parent::normalizeFileParam(
      (new FileParameter($this->anonymize($file_param->getPath(), true)))
        ->setMimeType($file_param->getMimeType())
        ->setName($file_param->getName()));
  }

  /**
   * @param int|float|string|bool $variable
   * @param bool $is_file
   * @return int|float|string|bool
   */
  protected function anonymizeScalar($variable, $is_file = false) {
    $param = $this->getPlaceholderByValue($variable);
    if ($param !== null) {
      $variable = static::getPlaceholder($param, $is_file);
    }

    return $variable;
  }

  /**
   * @param mixed $variable
   * @param bool $is_file
   * @return mixed
   */
  public function anonymize($variable, $is_file) {
    $param = $this->getPlaceholderByValue($variable);
    if ($param !== null) {
      return static::getPlaceholder($param, $is_file);
    } else if ($variable instanceof AbstractObject) {
      $variable = $variable->exportData();
    }

    if (is_array($variable) || $variable instanceof \Traversable) {
      return $this->anonymizeTraversable($variable, $is_file);
    } else if (is_object($variable)) {
      return $this->anonymizeObject($variable, $is_file);
    } else if (is_scalar($variable)) {
      return $this->anonymizeScalar($variable, $is_file);
    }

    return $variable;
  }

  /**
   * @param Parameters $params
   * @param string $flag
   * @param bool $is_file
   * @return string
   */
  protected function processParams(Parameters $params, $flag, $is_file) {
    $params = clone $params;
    foreach ($this->getParamsIgnoreList() as $param) {
      $params->offsetExists($param) && $params->offsetUnset($param);
    }

    $params = $this->anonymize($params, $is_file);

    foreach ($this->getParamsEnforceList() as $param) {
      $params->offsetExists($param) && $params->offsetSet(
        $param, static::getPlaceholder($param, $is_file));
    }

    return parent::processParams(
      new Parameters($params), $flag, false);
  }

  /**
   * @param RequestInterface $request
   * @return string
   */
  protected function processUrl(RequestInterface $request) {
    $request = clone $request;

    $components = explode('/', $request->getPath());
    foreach ($components as &$component) {
      $varname = $this->getPlaceholderByValue($component);
      if ($varname !== null) {
        $component = static::getPlaceholder($varname);
      }
    }

    $request = clone $request;
    $request->setPath(implode('/', $components));

    return parent::processUrl($request);
  }

  /**
   * @param string $instruction_type
   * @param array $argv
   */
  public function instruct($instruction_type, array $argv = array()) {
    if (!in_array(
      $instruction_type,
      $this->getInstructionIgnoreList()->getArrayCopy())) {

      $this->instructPassthru($instruction_type, $argv);

      if ($instruction_type === 'open') {
        // Initialize _DOC vars for enforced params
        $this->instruct('vars', $this->getParamsEnforceList()->getArrayCopy());
      }
    }
  }
}
