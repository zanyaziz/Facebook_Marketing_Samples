<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocsmith\Runner;

use FacebookAdsDocsmith\ExitCodesEnum;
use FacebookAdsDocsmith\ResultPrinter;
use FacebookAdsDocsmith\Runner\ErrorDecoderMethod\ErrorDecoderMethodInterface;
use FacebookAdsDocsmith\Runner\ErrorDecoderMethod\IsApiErrorCode;
use FacebookAdsDocsmith\Runner\ErrorDecoderMethod\IsExplicitSkip;
use FacebookAdsDocsmith\Runner\ErrorDecoderMethod\IsServerFaultMessage;
use FacebookAdsDocsmith\Runner\ErrorDecoderMethod\IsSuccess;
use FacebookAdsDocsmith\Runner\ErrorDecoderMethod\IsTransient;

class ErrorDecoder {

  /**
   * @var ResultPrinter
   */
  protected $printer;

  /**
   * @param ResultPrinter $printer
   * @return $this
   */
  public static function factory(ResultPrinter $printer) {
    return (new self($printer))
      ->register(new IsExplicitSkip())
      ->register(new IsSuccess())
      ->register(new IsTransient())
      ->register(new IsApiErrorCode())
      ->register(new IsServerFaultMessage())
      ;
  }

  public function __construct(ResultPrinter $printer) {
    $this->printer = $printer;
  }

  /**
   * @return ResultPrinter
   */
  public function getPrinter() {
    return $this->printer;
  }

  /**
   * @var array
   */
  protected $methods = array();

  /**
   * @param ErrorDecoderMethodInterface $method
   * @return $this
   */
  public function register(ErrorDecoderMethodInterface $method) {
    array_push($this->methods, $method);

    return $this;
  }

  /**
   * @param \PHPUnit_Framework_TestResult $result
   * @return int
   */
  public function decode(\PHPUnit_Framework_TestResult $result) {
    /** @var ErrorDecoderMethodInterface $method */
    foreach ($this->methods as $method) {
      if ($method->isMatch($result)) {
        $message = $method->getMatchLogMessage();
        if ($message !== null) {
          $this->getPrinter()->writeError($message.PHP_EOL);
        }

        return $method->getExitCode();
      }
    }

    return ExitCodesEnum::USER_ERROR;
  }
}
