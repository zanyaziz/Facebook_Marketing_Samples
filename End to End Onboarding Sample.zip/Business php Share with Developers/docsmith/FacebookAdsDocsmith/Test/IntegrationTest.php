<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocsmith\Test;

use FacebookAdsDoc\Helper\AbstractHelper;
use FacebookAdsDocsmith\Http\Adapter\RelayAdapter;
use FacebookAdsDocsmith\Runner;
use FacebookAdsDocsmith\Runner\OptionsEnum;
use FacebookAdsTest\AbstractIntegrationTestCase;

class IntegrationTest extends AbstractIntegrationTestCase {
  use DocsmithTestTrait;

  /**
   * @var Runner
   */
  protected $runner;

  /**
   * @param Runner $runner
   */
  public function __construct(Runner $runner) {
    parent::__construct('testDocExample');

    $this->runner = $runner;
  }

  /**
   * @return Runner
   */
  public function getRunner() {
    return $this->runner;
  }

  protected function setupHttpClient() {
    parent::setupHttpClient();
    if ($this->getRunner()->getOptions()->offsetGet(OptionsEnum::HTTP_MOCK)) {
      $this->httpClient->setAdapter(new RelayAdapter($this->httpClient));
      AbstractHelper::setIsStubbed(true);
    } else {
      AbstractHelper::setIsStubbed(false);
    }
  }

  /**
   * @return string
   */
  public function getDocFilepath() {
    return $this->getRunner()->getDocFilepath();
  }

  public function testDocExample() {
    $test = $this;
    $config = $this->getConfig();
    $ggc = $this->getRunner()->getGraphGarbageCollector();

    require_once($this->getDocFilepath());
  }
}
