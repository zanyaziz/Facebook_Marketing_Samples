<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocsmith\Test;

use FacebookAds\Api;
use FacebookAdsDocsmith\CurlGenerator\Logger;
use FacebookAdsDocsmith\Http\Adapter\RelayAdapter;

/**
 * @method Api getApi()
 * @method void markTestSkipped($message = '')
 * @method void fail($message = '')
 */
trait DocsmithTestTrait {

  /**
   * @return bool
   */
  public function isHttpMocked() {
    return
      $this->getApi()->getHttpClient()->getAdapter() instanceof RelayAdapter;
  }

  /**
   * @param string $message
   * @throws \PHPUnit_Framework_SkippedTestError
   */
  public function skip($message = '') {
    $this->markTestSkipped($message);
  }

  /**
   * @param bool $condition
   * @param string $message
   */
  public function skipIf($condition, $message = '') {
    if ($condition) {
      $this->skip($message);
    }
  }

  /**
   * @param string $message
   */
  public function skipIfHttpMocked($message = '') {
    $this->skipIf($this->isHttpMocked(), $message);
  }

  /**
   * @param bool $condition
   * @param string $message
   */
  public function skipIfHttpMockedAnd($condition, $message = '') {
    $this->skipIf($this->isHttpMocked() && $condition, $message);
  }

  /**
   * @param string $message
   */
  public function skipIfHttpNotMocked($message = '') {
    $this->skipIf(!$this->isHttpMocked(), $message);
  }

  /**
   * @param bool $condition
   * @param string $message
   */
  public function skipIfHttpNotMockedAnd($condition, $message = '') {
    $this->skipIf(!$this->isHttpMocked() && $condition, $message);
  }

  /**
   * @param $condition
   * @param string $message
   * @thrown \PHPUnit_Framework_AssertionFailedError
   */
  public function failIf($condition, $message = '') {
    if ($condition) {
      $this->fail($message);
    }
  }

  /**
   * @param mixed $var
   * @param string $name
   */
  public function mockCurlVariableIfHttpMocked(&$var, $name) {
    if ($this->isHttpMocked()) {
      /** @var Logger $logger */
      $logger = $this->getApi()->getLogger();
      $var = $logger->getPlaceholder($name);
    }
  }
}
