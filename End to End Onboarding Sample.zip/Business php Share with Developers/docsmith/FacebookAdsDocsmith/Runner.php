<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

namespace FacebookAdsDocsmith;

use FacebookAdsDocsmith\GraphGarbageCollector\GraphGarbageCollector;
use FacebookAdsDocsmith\Runner\ActionsEnum;
use FacebookAdsDocsmith\Runner\ActionStrategy\ActionStrategyInterface;
use FacebookAdsDocsmith\Runner\ActionStrategy\GenCurlActionStrategy;
use FacebookAdsDocsmith\Runner\ActionStrategy\TestActionStrategy;
use FacebookAdsDocsmith\Runner\ErrorDecoder;
use FacebookAdsDocsmith\Runner\OptionsEnum;
use FacebookAdsTest\AbstractTestCase;

final class Runner {

  /**
   * @var Runner
   */
  protected static $instance;

  /**
   * @var string
   */
  protected $action;

  /**
   * @var ActionStrategyInterface
   */
  protected $actionStrategy;

  /**
   * @var string
   */
  protected $docFilepath;

  /**
   * @var \ArrayObject
   */
  protected $options;

  /**
   * @var GraphGarbageCollector
   */
  protected $graphGarbageCollector;

  /**
   * @var \PHPUnit_TextUI_TestRunner
   */
  protected $testRunner;

  /**
   * @var AbstractTestCase|null
   */
  protected $testCase;

  /**
   * @var ResultPrinter
   */
  protected $printer;

  /**
   * @var \PHPUnit_Framework_TestSuite
   */
  protected $testSuite;

  /**
   * @var ErrorDecoder|null
   */
  protected $errorDecoder;

  public static function printUsage() {
    echo "Usage: docs_runner.php <ACTION> <PATH_TO_EXAMPLE_FILE>"
      ." [<OPTIONS>]".PHP_EOL;
    echo PHP_EOL;
    echo "Available actions:".PHP_EOL;
    foreach (ActionsEnum::getInstance()->getArrayCopy() as $action) {
      echo "  {$action}".PHP_EOL;
    }
    echo PHP_EOL;
    echo "Available options:".PHP_EOL;
    foreach (OptionsEnum::getInstance()->getArrayCopy() as $key => $option) {
      $key = strtolower(str_replace('_', ' ', $key));
      echo "  -{$option}: {$key}".PHP_EOL;
    }
    echo PHP_EOL;
  }

  /**
   * @param null|string $message
   */
  public static function throwInvalidUsage($message = null) {
    if ($message !== null) {
      echo "ERROR: ".$message.PHP_EOL;
    }
    static::printUsage();
    exit(1);
  }

  /**
   * @return Runner
   * @throws \LogicException
   */
  public static function getInstance() {
    if (self::$instance === null) {
      throw new \LogicException('Runner::getInstance() called before instance');
    }

    return self::$instance;
  }

  /**
   * @param string $action
   * @param string $doc_path
   * @param \ArrayObject $options
   * @throws \LogicException
   */
  public function __construct($doc_path, $action, \ArrayObject $options) {
    $this->docFilepath = $doc_path;
    $this->action = $action;
    $this->options = $options;

    if (self::$instance !== null) {
      throw new \LogicException(
        "An instance of ".get_called_class()." already exists");
    }

    self::$instance = $this;
  }

  /**
   * @return string
   */
  public function getDocFilepath() {
    return $this->docFilepath;
  }

  /**
   * @return \ArrayObject
   */
  public function getOptions() {
    return $this->options;
  }

  /**
   * @return GraphGarbageCollector
   */
  public function getGraphGarbageCollector() {
    if ($this->graphGarbageCollector === null) {
      $this->graphGarbageCollector = new GraphGarbageCollector(
        $this->getPrinter());
    }

    return $this->graphGarbageCollector;
  }

  /**
   * @return ActionStrategyInterface
   */
  public function getActionStrategy() {
    if ($this->actionStrategy === null) {
      switch ($this->action) {
        case ActionsEnum::GEN_CURL:
          $this->actionStrategy = new GenCurlActionStrategy();
          break;
        case ActionsEnum::TEST:
          $this->actionStrategy = new TestActionStrategy();
          break;
        default:
          throw new \InvalidArgumentException("Invariant action");
      }
    }

    return $this->actionStrategy;
  }

  /**
   * @return \PHPUnit_TextUI_TestRunner
   */
  public function getTestRunner() {
    if ($this->testRunner === null) {
      $this->testRunner = new \PHPUnit_TextUI_TestRunner();
      $this->testRunner->setPrinter($this->getPrinter());
    }

    return $this->testRunner;
  }

  /**
   * @return ResultPrinter
   */
  public function getPrinter() {
    if ($this->printer === null) {
      $this->printer = new ResultPrinter(
        $this->getActionStrategy()->getPrinterResource());
    }

    return $this->printer;
  }

  /**
   * @return \PHPUnit_Framework_TestSuite
   */
  public function getTestSuite() {
    if ($this->testSuite === null) {
      $this->testSuite = new \PHPUnit_Framework_TestSuite();
    }

    return $this->testSuite;
  }

  /**
   * @return AbstractTestCase
   */
  protected function createTestCase() {
    return $this->testCase = $this->getActionStrategy()->createTestCase($this);
  }

  /**
   * @return AbstractTestCase|null
   */
  public function getTestCase() {
    return $this->testCase;
  }

  /**
   * @return ErrorDecoder
   */
  public function getErrorDecoder() {
    if ($this->errorDecoder === null) {
      $this->errorDecoder = ErrorDecoder::factory($this->getPrinter());
    }

    return $this->errorDecoder;
  }

  /**
   * @return int
   */
  public function run() {
    $test_case = $this->createTestCase();
    $test_case_fqn = get_class($test_case);

    $this->getPrinter()->writeError('Testing '.$this->getDocFilepath().PHP_EOL);
    $this->getPrinter()->setDocFilepath($this->getDocFilepath());

    forward_static_call(array($test_case_fqn, 'setupBeforeClass'));

    $this->getTestSuite()->addTest($test_case);

    $result = null;

    try {
      $result = $this->getTestRunner()->doRun($this->getTestSuite());
    } catch (\Exception $e) {
      print $e->getMessage()."\n";
    }

    forward_static_call(array($test_case_fqn, 'tearDownAfterClass'));

    $this->getGraphGarbageCollector()->clean();

    return $result === null
      ? ExitCodesEnum::FAILURE
      : $this->getErrorDecoder()->decode($result);
  }
}
