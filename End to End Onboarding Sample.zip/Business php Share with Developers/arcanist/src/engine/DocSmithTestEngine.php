<?php

/**
 * TestEngine for DocSmith examples.
 *
 * @group unitrun
 */
final class DocSmithTestEngine extends ArcanistBaseUnitTestEngine {

  public function run() {
    $command = './bin/docsmith.php test';
    $doc_folder = 'docs/';

    /** @var ArcanistWorkingCopyIdentity $working_copy */
    $working_copy = $this->getWorkingCopy();

    $futures = array();
    $results = array();

    foreach ($this->getPaths() as $path) {
      if (strncmp($path, $doc_folder, strlen($doc_folder)) === 0 &&
        file_exists($path)) {
        $future = new ExecFuture('%C %C', $command, $path);
        $future->setCWD($working_copy->getProjectRoot());
        $futures[$path] = $future;
      }
    }

    /** @var Future $future */
    foreach (Futures($futures)->limit(1) as $test => $future) {
      list($err, $stdout, $stderr) = $future->resolve();

      $status = $err == 0 ?
        ArcanistUnitTestResult::RESULT_PASS :
        ArcanistUnitTestResult::RESULT_FAIL;

      $result = new ArcanistUnitTestResult();
      $result->setName($test);
      $result->setResult($status);
      $result->setUserData($stderr);
      $results[] = $result;
    }

    return $results;
  }
}
