<?php
/**
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

class TrailingCommaLinter extends ArcanistBaseXHPASTLinter {

  /**
   * @var array
   */
  private $futures = array();

  /**
   * @var array
   */
  private $trees = array();

  /**
   * @return string
   */
  public function getLinterName() {
    return 'TrailingComma';
  }

  // Copied from ArcanistXHPASTLinter
  protected function buildFutures(array $paths) {
    foreach ($paths as $path) {
      if (!isset($this->futures[$path])) {
        $this->futures[$path] = xhpast_get_parser_future($this->getData($path));
      }
    }
    return array_select_keys($this->futures, $paths);
  }

  // Copied from ArcanistXHPASTLinter
  public function getCacheVersion() {
    $version = '4';
    $path = xhpast_get_binary_path();
    if (Filesystem::pathExists($path)) {
      $version .= '-'.md5_file($path);
    }
    return $version;
  }

  // Copied from ArcanistXHPASTLinter
  public function getXHPASTTreeForPath($path) {
    if (!array_key_exists($path, $this->trees)) {
      $this->trees[$path] = null;
      try {
        $this->trees[$path] = XHPASTTree::newFromDataAndResolvedExecFuture(
          $this->getData($path),
          $this->futures[$path]->resolve());
        $root = $this->trees[$path]->getRootNode();
        $root->buildSelectCache();
        $root->buildTokenCache();
      } catch (XHPASTSyntaxErrorException $ex) {
        $this->raiseLintAtLine(
          $ex->getErrorLine(),
          1,
          ArcanistXHPASTLinter::LINT_PHP_SYNTAX_ERROR,
          'This file contains a syntax error: '.$ex->getMessage());
      } catch (Exception $ex) {
        $this->raiseLintAtPath(
          ArcanistXHPASTLinter::LINT_UNABLE_TO_PARSE,
          $ex->getMessage());
      }
    }
    return $this->trees[$path];
  }

  /**
   * Check if tokens are spread across multiple lines.
   *
   * @param $tokens
   * @return bool
   */
  protected function isMultiline($tokens) {
    foreach ($tokens as $token) {
      if ($this->isNewline($token)) {
        return true;
      }
    }
    return false;
  }

  /**
   * Check if token is a comma.
   *
   * @param $token
   * @return bool
   */
  protected function isComma($token) {
    return $token->getTypeName() == ',';
  }

  /**
   * Check if token is a newline.
   *
   * @param $token
   * @return bool
   */
  protected function isNewline($token) {
    $value = $token->getValue();
    return $token->isAnyWhitespace() && $value == "\n";
  }

  /**
   * Called by Arcanist
   *
   * @param $path
   * @param Future $future
   */
  protected function resolveFuture($path, Future $future) {
    $tree = $this->getXHPASTTreeForPath($path);
    if (!$tree) {
      return;
    }

    $root = $tree->getRootNode();

    $array_literals = $root->selectDescendantsOfType('n_ARRAY_LITERAL');
    foreach ($array_literals as $array_literal) {
      $tokens = $array_literal->getTokens();
      $this->checkTrailingComma($tokens);
    }
  }

  /**
   * Check if tokens end with a traling comma. Otherwise raise a lint error.
   *
   * @param $tokens
   */
  protected function checkTrailingComma($tokens) {
    $count = count($tokens);
    if ($count >= 3 && $this->isMultiline($tokens)) {
      list($comma) = array_slice($tokens, $count - 3, $count - 3);
      list($newline) = array_slice($tokens, $count - 2, $count - 2);
      if (!$this->isComma($comma) || !$this->isNewline($newline)) {
        $this->raiseLintAtOffset(
          $newline->getOffset(),
          "F900",
          "Missing trailing comma");
      }
    }
  }

}
