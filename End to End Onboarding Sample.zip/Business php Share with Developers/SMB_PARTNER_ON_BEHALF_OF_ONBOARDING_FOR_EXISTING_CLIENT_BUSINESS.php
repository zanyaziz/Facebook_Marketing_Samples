<?php
/**
 * Copyright (c) 2015-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use
 * of this software is subject to the Facebook Developer Principles and
 * Policies [http://developers.facebook.com/policy/]. This copyright notice
 * shall be included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * This script shows an example of how a partners can setup a child Business
 * Manager on behalf of an advertiser using the clients access token. This
 * new child busines manager is entirely owned by the Partners Business
 * Manager and allows the Partner to organize the Advertisers assets within
 * a child business manager that they own. Each child business manager has its
 * own admin System User which is used for reating/managing ads on behalf of
 * the advertiser. The Admin System user of they child business manager can
 * be used to create an Ad Account and other assets all contained within child
 * business manager. This allows partners to organize the assets of each
 * advertiser within a child BM to be used only for them. This allows the
 * partner to on board new advertisers in a scalable secure manner.
 */

echo "An example script that shows how to create an on behalf client business
manager.".PHP_EOL;
/**
* NOTE: You can use these new API endpoints only if your app has the capability
* to create children business managers. This can be requested by reaching out
* to Facebook and requesting for that app capability.
*/

// Import Marketing API SDK References.
use FacebookAds\Api;
use FacebookAds\Logger\CurlLogger;
use FacebookAds\Object\AdAccount;
use FacebookAds\Object\Campaign;
use FacebookAds\Object\Fields\AdAccountFields;
use FacebookAds\Object\Fields\CampaignFields;
use FacebookAds\Http\RequestInterface;
use FacebookAds\Object\Targeting;
use FacebookAds\Object\Fields\TargetingFields;
use FacebookAds\Object\AdSet;
use FacebookAds\Object\Fields\AdSetFields;
use FacebookAds\Object\Values\AdSetBillingEventValues;
use FacebookAds\Object\Values\AdSetOptimizationGoalValues;
use FacebookAds\Object\Ad;
use FacebookAds\Object\Fields\AdFields;
use FacebookAds\Object\AdImage;
use FacebookAds\Object\Fields\AdImageFields;
use FacebookAds\Object\AdCreative;
use FacebookAds\Object\AdCreativeLinkData;
use FacebookAds\Object\Fields\AdCreativeLinkDataFields;
use FacebookAds\Object\AdCreativeObjectStorySpec;
use FacebookAds\Object\Fields\AdCreativeObjectStorySpecFields;
use FacebookAds\Object\Fields\AdCreativeFields;
use FacebookAds\Object\Business;
use FacebookAds\Object\Fields\BusinessFields;
use FacebookAds\Object\ExtendedCredit;
use FacebookAds\Object\AdUser;
use FacebookAds\Object\Fields\AdUserFields;
use FacebookAds\Object\Page;

// *** Replace the constants below ***
// Partner Info:
$app_id = '';  //Paste App ID here.
$app_secret = ''; //Paste App Secret here.
$partner_access_token = ''; // Paste the Admin System user under partners business manager here. The Admin system user needs to have Finance editor role which can be granted through the Business Manager UI. (Click on edit system user and assign Finance Editor role.)
$partner_bm_id = '';  // Paste the business manager of the Partner here.

// *** Replace the constants below ***
// Advertisers Info
// This is the access token of the advertiser(client) which should have manage_ads and business_manage permission.
$client_access_token = '';
$existing_client_biz_id = '';

// ----------------------------------------------------------
define('SDK_DIR', __DIR__ ); // Path to the SDK directory
$loader = include SDK_DIR.'/vendor/autoload.php';

if (is_null($partner_access_token)
  || is_null($app_id)
  || is_null($app_secret))
{
  throw new \Exception(
    'You must set your access token, app id and app secret before executing'
  );
}

function getApi($api, $params, $fields, $node_id, $edge) {
  if ($fields) {
    $fields = implode(',', $fields);
    $params['fields'] = $fields;
  }
  $response = $api->call(
    '/'.$node_id.'/'.$edge, RequestInterface::METHOD_GET, $params);
  return $response->getContent();
}

function postEdges($api, $params, $node_id, $edge){
  $response = $api->call(
    '/'.$node_id.'/'.$edge, RequestInterface::METHOD_POST, $params);
  echo var_dump($response->getBody()).PHP_EOL;
  return $response->getContent();
}

function setAccessToken($access_token) {
  global $app_secret, $app_id;
  Api::init($app_id, $app_secret, $access_token);
  $api = Api::instance();
  $logger = new CurlLogger();
  $api->setLogger($logger);
  return $api;
}

function postCurl($url, $params) {
  // Get cURL resource
  $curl = curl_init();
  curl_setopt_array($curl, array(
      CURLOPT_RETURNTRANSFER => 1,
      CURLOPT_URL => $url,
      CURLOPT_POST => 1,
      CURLOPT_POSTFIELDS => $params
  ));
  // Send the request & save response to $resp
  $resp = curl_exec($curl);
  // Close request to clear up some resources
  curl_close($curl);

  return json_decode($resp, true);
}

function getAppSecretProof($access_token, $app_secret) {
  return hash_hmac('sha256',$access_token, $app_secret);
}

try{
  /**
   * Step 1 Use advertisers access token to create a client BM
   * This can be fetched by integrating the Facebook login button on
   * your webpage and fetching the advertisers access token after
   * the login. The Advertiser user which owns this access token would be admin
   * of the client BM
   * The partner has no root access to the client BM.
   */

echo 'Creating client business manager...'.PHP_EOL;
  $url_managed_biz_url =
    sprintf('https://graph.facebook.com/v3.1/%s/managed_businesses', $partner_bm_id);
  $params = array(
      'id' => $partner_bm_id,
      'existing_client_business_id' => $existing_client_biz_id,
      'access_token' => $client_access_token,
      'appsecret_proof' => getAppSecretProof($client_access_token, $app_secret),
  );
  $response = postCurl($url_managed_biz_url, $params);
  print_r($response);
  $child_business_id = $response['id'];
  echo 'Client business id is:'.$child_business_id.PHP_EOL;

  /**
   * Step 2 Create access token of system user under client BM.
   * This uses the partners access token.
   */
  echo 'Fetch access token of child business managers system user...'.PHP_EOL;
  $api = setAccessToken($partner_access_token);
  $child_business_token = (new Business($child_business_id))->createAccessToken(
    array(),
    array(
      'id' => $child_business_id,
      'app_id' => $app_id,
      'scope' => 'manage_pages,ads_management,business_management',
    ));
  $child_bm_system_user_access_token = $child_business_token->access_token;
  echo "Child BM System User Access Token:".
    $child_bm_system_user_access_token.PHP_EOL;

  /**
   * Step 3 Create Ad Account under the new child business manager.
   * This uses the client BMs system users access token.
   * The System user for their client BM is the owner of the Ad Account.
   */
  echo 'Creating Ad Account within child business manager...'.PHP_EOL;
  $api = setAccessToken($client_access_token);
  $account = (new Business($child_business_id))->createAdAccount(
    array(),
    array(
      'name' => 'Advertisers Ad Account',
      'currency' => 'USD',
      'timezone_id' => 1,
      'end_advertiser' => $child_business_id,
      'media_agency' => 'NONE',
      'partner' => 'NONE',
      // 'funding_id' => $child_bm_payment_method_id,
    ));
  $account_id = $account->id;
  echo "Account Id:".$account_id.PHP_EOL;

  /**
   * Step 4 Fetch the System user for the client business. This uses the client
   * BMs access token. This system user id is used in the api calls below.
   */
  echo 'Fetching the id of system users within child
    business manager...'.PHP_EOL;
  $api = setAccessToken($client_access_token);
  $system_user_id = (new Business($child_business_id))
    ->getSystemUsers(array(), array())[0]->id;
  echo "System User Id:".$system_user_id.PHP_EOL;

  /**
   * Step 5 Add System user as Admin to Ad Account.
   * This uses the client BMs access token.
   */
  echo 'Grant system user within child business manager admin priviledge
    to be able to manage ads...'.PHP_EOL;
  $api = setAccessToken($client_access_token);
  (new AdAccount($account_id))->createAssignedUser(array(), array(
    'user' => $system_user_id,
    'tasks' => 'MANAGE,ADVERTISE,ANALYZE',
    'business' => $child_business_id,
  ));

  // END ONBOARDING FLOW


  // How to create a new Ad in the Ad accound under the new client BM
  /**
   * Step 1 Create the Campaign
   */
  echo 'Creating Ad Campaign...'.PHP_EOL;
  $api = setAccessToken($child_bm_system_user_access_token);
  $account = new AdAccount($account_id);
  $campaign  = $account->createCampaign(array(),
    array(
        CampaignFields::NAME => 'First test Campaign',
        CampaignFields::OBJECTIVE => 'LINK_CLICKS',
        CampaignFields::STATUS => 'PAUSED',
    ));
  echo "Campaign ID:" . $campaign->id.PHP_EOL;

  /**
   * Step 2 Search Targeting
   */
  $targeting = new Targeting();
  $targeting->setData(array(
      TargetingFields::GEO_LOCATIONS => array(
          'countries' => array('JP'),
          'regions' => array(array('key' => '3886')),
          'cities' => array(
              array(
                  'key' => '2420605',
                  'radius' => 10,
                  'distance_unit' => 'mile',
              ),
          ),
      ),
  ));

  /**
  * Step 3 Create the AdSet
  */
  echo 'Creating Adset...'.PHP_EOL;
  $start_time = (new \DateTime("+1 week"))->format(DateTime::ISO8601);
  $end_time = (new \DateTime("+2 week"))->format(DateTime::ISO8601);
  $fields = array(
  );
  $params = array(
   AdSetFields::NAME => 'First Ad Set',
   AdSetFields::OPTIMIZATION_GOAL => AdSetOptimizationGoalValues::REACH,
   AdSetFields::BILLING_EVENT => AdSetBillingEventValues::IMPRESSIONS,
   AdSetFields::BID_AMOUNT => 2,
   AdSetFields::DAILY_BUDGET => 1000,
   AdSetFields::CAMPAIGN_ID => $campaign->id,
   AdSetFields::TARGETING => $targeting,
   AdSetFields::START_TIME => $start_time,
   AdSetFields::END_TIME => $end_time,
  );
  $ad_set = $account->createAdSet(
   $fields,
   $params
  );
  $ad_set_id = $ad_set->id;
  echo 'Ad Set ID: ' . $ad_set_id.PHP_EOL;

  /**
   * Step 4 Create an AdImage
   */
  echo 'Creating an AdImage...'.PHP_EOL;
  $image = new AdImage();
  $image->setParentId($account->id);
  $image->{AdImageFields::FILENAME}
      = SDK_DIR.'/test/misc/image.png';

  $image->create();
  echo 'Image Hash: '.$image->hash.PHP_EOL;
  $image_hash = $image->hash;

  /**
   * Step 5 Create an AdCreative
   */
  echo 'Creating an AdCreative...'.PHP_EOL;
  $link_data = new AdCreativeLinkData();
  $link_data->setData(array(
    AdCreativeLinkDataFields::MESSAGE => 'try it out',
    AdCreativeLinkDataFields::LINK => 'http://www.google.com',
    AdCreativeLinkDataFields::IMAGE_HASH => $image->hash,
  ));

  $object_story_spec = new AdCreativeObjectStorySpec();
  $object_story_spec->setData(array(
    AdCreativeObjectStorySpecFields::PAGE_ID => $page_id,
    AdCreativeObjectStorySpecFields::LINK_DATA => $link_data,
  ));
}
catch (Exception $e) {
    echo 'Error message: ' .$e->getMessage() .PHP_EOL;
    echo 'Error Code: ' .$e->getCode() .PHP_EOL;
}
?>
